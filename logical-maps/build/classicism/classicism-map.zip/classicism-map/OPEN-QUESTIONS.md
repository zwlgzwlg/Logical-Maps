# Open questions — Classicism

Conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (4)

#### Possible Infinity (type t) ⇒ Axiom of Infinity (type t) — `possible-infinity-t-implies-axiom-of-infinity-t`

**Answer: Open.**

Original record notes:

Equivalent to the claim that a finite count of propositions is necessary whenever it is true. It holds with No Pure Contingency and with BF (type $t$), by the recorded results. If some finite $Z$ holds of $\lambda p\, .\,\top$ then every proposition is one of finitely many, and NI carries each identity across, but collecting them under a box is an instance of BF at type $t$, which C does not prove. A proof would need to bypass that; a countermodel would need a world with finitely many propositions that can see one with more, and must violate both BF (type $t$) and No Pure Contingency.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-t-implies-axiom-of-infinity-t.yaml`.

#### Relational Choice ∧ Boolean Completeness ⇒ Transversal Choice — `relational-choice-and-boolean-completeness-imply-transversal-choice`

**Answer: Open.**

Original record notes:

Does adding Boolean Completeness to Relational Choice suffice for Transversal Choice in C? The question without Boolean Completeness is recorded separately. No proof was supplied. A proof of this implication, or a model of C satisfying both premises and failing Transversal Choice, would settle this conjecture.

- **Goodsell 27 Sep** — Zachary Goodsell, conjecture communicated on 27 September 2026: Relational Choice + Boolean Completeness ⊢ Transversal Choice.

Record: `topics/classicism/results/relational-choice-and-boolean-completeness-imply-transversal-choice.yaml`.

#### Relational Choice ⇒ Transversal Choice — `relational-choice-r-implies-transversal-choice-r`

**Answer: Open.**

Original record notes:

Does Relational Choice alone give a transversal for every equivalence relation? Christopher Sun observed that the literature claims this without proof. The converse is recorded. The quotient argument chooses from each cell $\lambda z\, .\,(Rx)z$ and needs the cells of two members of one class to be the same property; in C that is necessary coextension, and the hypothesis gives actual coextension only. No definable substitute for the cell helps, since an operation definable from $R$ identifies $x$ with $x'$ only when they are necessarily indiscernible with respect to $R$. A Zermelo-style well-ordering argument breaks at the same point: coextensive but distinct stages receive different chosen elements. The expectation is that the implication fails. What would settle it: a proof that uses the chosen relation to break the symmetry between coextensive cells, or a model of C with Relational Choice that is not extensionally full at its evaluation point. Every recorded model of Relational Choice is extensionally full there, in that every set of tuples from the domains is the extension of a rigid element, and that fullness verifies Transversal Choice by the same metatheoretic choice, so none separates the two. Symmetric Henkin models in the Fraenkel–Mostowski style cannot separate them either; see the write-up.
Update of 28 September 2026: Christopher Sun showed on 26 September that Transversal Choice is equivalent to Relational Choice together with Transversal (transversal-and-relational-choice-imply-transversal-choice), so this question is equivalent to whether Relational Choice implies Transversal. Anything that implies Transversal, such as Actuality, closes the gap.

- **Sun via Goodsell 25 Sep** — Christopher Sun, observation communicated by Zachary Goodsell on 25 September 2026, that the transversal formulation of choice is claimed in the literature without a proof from Relational Choice.

Record: `topics/classicism/results/relational-choice-r-implies-transversal-choice-r.yaml`.

#### Strong Possibility (signature Σ) ⇒ Strong Possibility (pure) — `strong-possibility-signature-r-implies-strong-possibility-r`

**Answer: Open.**

Original record notes:

The restriction of the signature schema to pure P gives ◇≠P for every pure P consistent with Max(C(Σ)); the pure schema asks for every pure P consistent with Max(C). So the arrow holds iff Max(C(Σ)), equivalently Max(C) plus Separated Structure, is conservative over Max(C) for pure sentences: every pure sentence consistent with Pure Maximalist Classicism must remain consistent when Separated Structure is added. Adjoining constants is conservative for C, which is why Possibility Maximalism (signature Σ) implies Possibility Maximalism (pure), but for the maximalization a model of Max(C) + P would need its constants interpreted so that each realizes every consistent role at some truncation, which is not automatic. A proof of that conservativity, or a pure sentence consistent with Max(C) but not with Max(C) + Separated Structure, would settle it.

- **Dorr 22 Sep** — Cian Dorr, suggestion of 22 September 2026.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.5, p. 39; §2.6, p. 42.

Record: `topics/classicism/results/strong-possibility-signature-r-implies-strong-possibility-r.yaml`.

### 1.2 Resolved (24)

#### Actuality ∧ BF ⇒ Inextensible Comprehension — `actuality-and-bf-imply-inextensible-comprehension`

**Answer: Proved.**

Supporting result ids: `actuality-and-bf-imply-inextensible-comprehension`.

Original record notes:

BF is used only at the actual world, at the type $\bar\sigma t$ of $X$ and at the argument types $\bar\sigma$, to bring the quantifiers in the negated leading box of inextensibility out to the actual world, where Actuality can be applied to the chosen instances. This strengthens the earlier result from □BF and Actuality, which now follows from it. The identifier was first used on 26 September 2026 for this claim as a conjecture, which was withdrawn the same day because the recorded argument then needed □BF.

- **Sun, 26 Sep** — Christopher Sun, argument communicated to Cian Dorr on 26 September 2026 and reported by him on 27 September 2026; see the write-up.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, pp. 28–30 (inextensibility); Proposition 2.1, pp. 20–21 (BF).

Record: `topics/classicism/results/actuality-and-bf-imply-inextensible-comprehension.yaml`.

#### □ND ∧ Atomicity ⇒ No Pure Contingency — `c5-and-atomicity-imply-no-pure-contingency`

**Answer: Proved.**

Supporting result ids: `c5-and-atomicity-imply-no-pure-contingency`.

Original record notes:

Reported by the source as a theorem of Goodsell and Yli-Vakkuri, without a proof; recorded as conjectured on 17 September 2026 pending verification, and promoted on 23 September 2026 with an independent proof, sketched by Cian Dorr with permission from Zachary Goodsell. Only the type-t instance of Atomicity is used; the record c5-and-atomicity-t-imply-no-pure-contingency states that sharper form and this record is derivable from it. □ND is used through ND (rigidity of identity propositions at each type) and BF (commutation of the atom-exchanging automorphism with the quantifiers, and rigidity of the hypothesis that the two atoms are distinct).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.2, p. 27.
- **Dorr 23 Sep** — Cian Dorr, proof sketch of 23 September 2026, with permission from Zachary Goodsell; written out in the write-up.

Record: `topics/classicism/results/c5-and-atomicity-imply-no-pure-contingency.yaml`.

#### Distinctness Maximalism (pure) ∧ Rigid Comprehension ⇒ ⊥ — `maximalist-distinctness-incompatible-with-rigid-comprehension`

**Answer: Proved.**

Supporting result ids: `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Original record notes:

Recorded on 17 September 2026 as a reported theorem awaiting a supplied proof. The proof is now Goodsell's own, imported from Arithmetic is Necessary, and the record is derivable from the recorded chain through Boolean Completeness, Countable Boolean Completeness and the Necessity of Arithmetic.

- **Arithmetic is Necessary** — Zachary Goodsell, Arithmetic is Necessary, draft of 5 June 2024, §6, Theorem 11 and the remark following it, p. 25.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, p. 41.

Record: `topics/classicism/results/maximalist-distinctness-incompatible-with-rigid-comprehension.yaml`.

#### □Atomicity ∧ Boolean Completeness ∧ BF ⇒ Rigid Comprehension — `necessary-atomicity-completeness-bf-imply-rigid-comprehension`

**Answer: Refuted.**

Supporting result ids: `necessary-boolean-completeness-r-implies-boolean-completeness-r`, `necessary-barcan-r-implies-barcan-r`.

Model witness ids: `ultralimit-fork`.

Original record notes:

Downgraded from proved to conjectured on 28 September 2026, at Cian Dorr's request. The source's proof (Proposition 2.11, note 42) has two gaps, found that day by an agent working in the Lean-Classicism formalization project; the write-up sets out the paper's argument with the gaps marked. (a) Part (iv) of note 42 boxes a claim that holds pointwise in the object variables by BF, where □BF would be needed. Cian Dorr agreed. (b) The same part's "without loss of generality" step replaces the atom $w'$ by $w''$, the greatest lower bound of the propositions $p$ with $w\le(p=w')$. The proof then needs $w\le(w''=w')$, so that $w''$ is still possible and below $X^*z\land\neg Yz$ where $w$ holds; nothing in the premises gives this, and □BF does not help. A propositional structure in which that step fails is sketched in the project's VERIFICATION.md; it has not been extended to a model of C with all the premises, so it shows that the step needs an argument, not that the proposition is false. What is proved there: Actuality, Boolean Completeness and BF (at the relevant types), together with a restriction principle, give Rigid Comprehension with the paper's witness $X^*$. The restriction principle says that for all $p,q$ there is an $r$ with $p\le(r=q)$ such that $r\le s$ whenever $p\le(q\le s)$. It holds in C5, with $r:=q\land\Diamond p$. Restructured this way, gap (a) disappears, and gap (b) becomes the question whether the premises here give the restriction principle. What would settle the conjecture: a derivation of the restriction principle, or another argument, from boxed Atomicity, Boolean Completeness and BF; or a model of C with those three principles that fails Rigid Comprehension. The source's first cross-reference to Proposition 2.6 was replaced in the earlier transcription by Proposition 2.7; the statement and premises are unchanged.

Refuted, 1 October 2026: the model ultralimit-fork, from Branden Fitelson (with Claude and GPT-6 Astra), satisfies Classicism, □Atomicity, □Boolean Completeness, □BF and □Actuality, and fails Rigid Comprehension at type $t\to t$. It extends the propositional structure mentioned above to a model of C with all the premises, so gap (b) is a genuine gap. The record stays conjectured, as the map's convention requires; the model is the refuting evidence. Gap-free in the end is part (ii), which gets Actuality: Atomicity (type $t$) and Weak Inextensible Comprehension imply Actuality (atomicity-t-and-weakly-inextensible-comprehension-imply-actuality), and Boolean Completeness implies Weak Inextensible Comprehension.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Proposition 2.11, p. 30 and n. 42.

Record: `topics/classicism/results/necessary-atomicity-completeness-bf-imply-rigid-comprehension.yaml`.

#### Possible Infinity (type e) ⇒ Axiom of Infinity (type e) — `possible-infinity-e-implies-axiom-of-infinity-e`

**Answer: Refuted.**

Supporting result ids: `possibility-plus-r-implies-possibility-schema-r`, `possibility-schema-r-implies-possible-infinity-e`, `axiom-of-infinity-e-implies-infinity-e`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Equivalent to the claim that a finite count of individuals is necessary whenever it is true. It holds with No Pure Contingency and with BF, by the recorded results. A countermodel would need a world with finitely many individuals that can see one with more, and must violate both BF at type $e$ and No Pure Contingency; the coalesced sums on the map do not supply one, since their roots have infinitely many individuals.

- **Dorr 20 Sep** — Cian Dorr, question of 20 September 2026.

Record: `topics/classicism/results/possible-infinity-e-implies-axiom-of-infinity-e.yaml`.

#### Coalesced sum: maximalist root — `coalesced-maximalist-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `strong-possibility-and-distinctness-preserving-collapse-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `barcan-r-implies-barcan-t`, `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-possibility-schema-r`, `possibility-and-necessary-relational-choice-incompatible`, `boolean-completeness-r-implies-countable-boolean-completeness-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `coalesced-maximalist-root`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Atomicity fails at type t: C is complete for the components, so some component $M$ refutes Atomicity at its root, by a proposition $p_M$ with no atom below it in $M$’s domain; the root proposition that is $p_M$ on $M$, empty on every other component and false at the root has as its root lower bounds exactly the root propositions that are lower bounds of $p_M$ on $M$ and empty elsewhere, so it has no atom below it either. Boolean Completeness fails, at type $e\to t$, for the same reason: a component $M$ refutes it by a property $X_M$ of propositions without a greatest lower bound in $M$’s domain, and the root property holding of a root proposition iff $X_M$ holds of its $M$-component has no greatest lower bound at the root, since such a bound’s $M$-component would be one for $X_M$. Relational Choice holds at the root, contrary to a first guess: the functionality of a subrelation is evaluated at the root’s identity arrow only, while the subrelation condition is boxed; so for a serial root relation take the subrelation whose root component is a functional choice from the root component, by choice in the metatheory, and whose component parts are empty. The Axiom of Infinity at type e holds: the root individuals are all families of component individuals, infinitely many since components have arbitrarily many individuals; identity at the root is identity of families; and the property of cardinalities that is true of exactly the standard numerals at the root and universal in every component is a root entity, so a finite cardinality at the root is a standard numeral, and no standard numeral holds of the universal property over an infinite domain. □Relational Choice fails, as the notes on Relational Choice explain: some component refutes Relational Choice at its root, which is accessible from the root. Correction of 23 September 2026: the components are only known to refute Boolean Completeness at type $e\to t$ (Classicism, n. 92, conjectures failures at type $t$ but has none), so the transfer argument refutes the type schema of Boolean Completeness at the root, not its type-$t$ instance, which is left unknown; the same transfer, applied to the countable family of haecceities that witnesses the component failure, refutes Countable Boolean Completeness. Boolean Completeness fails at type $t$ (restoring the claim corrected earlier in the day): the truncation model of Appendix D, part 6, refutes it at type $t$, as its record now shows, and the components are complete for C, so one of them does; the root propositions false at every arrow except those into that component form a copy of its propositional domain under the root’s entailment order, and a root property of propositions holding exactly of the copies of the members of that component’s counterexample family has no least upper bound at the root. □Transversal fails as well, by the same argument: the negation of the type-$e$ instance of Transversal is a pure sentence consistent with C, since it holds in symmetric-infinite-classes, so it is possible at the root. Observation of Claude Opus 5.5 (Anthropic), 28 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Theorem 3.26, §§3.6, pp. 62–64; Appendix E, pp. 80–83; §2.6, p. 41.

Record: `topics/classicism/models/coalesced-maximalist-root.yaml`.

#### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `strong-possibility-and-distinctness-preserving-collapse-incompatible`, `possibility-plus-r-implies-possibility-schema-r`, `possibility-schema-r-implies-possible-infinity-e`, `possible-infinity-e-and-bf-imply-axiom-of-infinity-e`, `axiom-of-infinity-e-implies-infinity-e`, `possibility-and-necessary-relational-choice-incompatible`, `boolean-completeness-r-implies-countable-boolean-completeness-r`, `possibility-and-countable-boolean-completeness-incompatible`.

Model witness ids: `coalesced-single-individual-root`.

Original record notes:

Promoted on 22 September 2026 for the pure package, which the source establishes; the earlier conjectured status concerned an expansion to the map’s signature Σ. That expansion exists exactly when Σ has at most one individual constant: with two, the unique root individual would have to be carried to two different interpretations in a component where they differ, which no arrow can do. So the signature principles are not listed; for a signature with individual constants see the constant-indexed root.
Actuality holds by the singleton root proposition; Infinity at type e fails at the root, where there is one individual, although infinitely many are possible. Atomicity fails at type t: C is complete for the components, so some component $M$ refutes Atomicity at its root, by a proposition $p_M$ with no atom below it in $M$’s domain; the root proposition that is $p_M$ on $M$, empty on every other component and false at the root has as its root lower bounds exactly the root propositions that are lower bounds of $p_M$ on $M$ and empty elsewhere, so it has no atom below it either. Boolean Completeness fails, at type $e\to t$, for the same reason: a component $M$ refutes it by a property $X_M$ of propositions without a greatest lower bound in $M$’s domain, and the root property holding of a root proposition iff $X_M$ holds of its $M$-component has no greatest lower bound at the root, since such a bound’s $M$-component would be one for $X_M$. Relational Choice holds at the root, contrary to a first guess: the functionality of a subrelation is evaluated at the root’s identity arrow only, while the subrelation condition is boxed; so for a serial root relation take the subrelation whose root component is a functional choice from the root component, by choice in the metatheory, and whose component parts are empty. □Relational Choice fails, as the notes on Relational Choice explain: some component refutes Relational Choice at its root, which is accessible from the root. Correction of 23 September 2026: the components are only known to refute Boolean Completeness at type $e\to t$ (Classicism, n. 92, conjectures failures at type $t$ but has none), so the transfer argument refutes the type schema of Boolean Completeness at the root, not its type-$t$ instance, which is left unknown; the same transfer, applied to the countable family of haecceities that witnesses the component failure, refutes Countable Boolean Completeness. Boolean Completeness fails at type $t$ (restoring the claim corrected earlier in the day): the truncation model of Appendix D, part 6, refutes it at type $t$, as its record now shows, and the components are complete for C, so one of them does; the root propositions false at every arrow except those into that component form a copy of its propositional domain under the root’s entailment order, and a root property of propositions holding exactly of the copies of the members of that component’s counterexample family has no least upper bound at the root. □Transversal fails as well, by the same argument: the negation of the type-$e$ instance of Transversal is a pure sentence consistent with C, since it holds in symmetric-infinite-classes, so it is possible at the root. Observation of Claude Opus 5.5 (Anthropic), 28 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.6, pp. 41–42 and n. 61; Appendix E, p. 83.

Record: `topics/classicism/models/coalesced-single-individual-root.yaml`.

#### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `no-contingency-signature-r-implies-signature-b-r`, `atomicity-r-implies-atomicity-t`, `atomicity-t-and-bf-t-imply-strong-leibniz-t`.

Model witness ids: `finite-support-dyadic-roundings`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Actuality and Atomicity hold because each $\{f_n\}$ is pinned down by a finite set ($\{n-2,n-1,n\}$ for $n>1$, $\{0,1\}$ for the identity); BF fails since an arrow sending $1$ to $0$ sends everything to even numbers; Boolean Completeness fails because the strongest persistent property with extension $\mathbb N$ pinned down by $\{0,\ldots,n\}$ has, at $f_m$, the multiples of $\min\{m,n\}$ as extension and so becomes ever stronger.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals.
Boolean Completeness already fails at type t: the finite/cofinite algebra of arrow indices has no least upper bound for the even-index singleton family.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 7, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-dyadic-roundings.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-dyadic-roundings.yaml`.

#### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `no-contingency-signature-r-implies-signature-b-r`, `atomicity-t-and-bf-imply-atomicity`.

Model witness ids: `finite-support-identity-or-collapse-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Restricting part 4 to surjections restores BF by Proposition D.6; Actuality holds as in part 4, and ND, Atomicity and Boolean Completeness fail as there.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 5, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse-surjections.yaml`.

#### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `no-contingency-signature-r-implies-signature-b-r`.

Model witness ids: `finite-support-identity-or-collapse`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Actuality holds because the identity is the only arrow that does not collapse $0$ and $1$, so $\{1_{\mathbb N}\}$ is pinned down by $\{0,1\}$; the actual world is the only world, Atomlessness restricted to false propositions holds, and Atomicity fails; BF, ND and Boolean Completeness fail as in part 3.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 4, pp. 74, 78 and n. 97; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-identity-or-collapse.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-identity-or-collapse.yaml`.

#### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-pure-contingency-and-nd-imply-necessary-nd`, `necessary-nd-implies-bf`, `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-possibility-schema-r`, `no-pure-contingency-r-implies-pure-b-r`, `pure-b-and-pure-possibility-incompatible`, `inextensible-comprehension-r-implies-weakly-inextensible-comprehension-r`.

Model witness ids: `finite-support-monotone-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
ND, Actuality and Atomicity fail, Atomlessness holds, and Boolean Completeness fails as in part 2.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. So $\langle b,i\rangle\in Y\setminus B_{N^{\prime}}$, and $Y$ is not even weakly inextensible, so Weakly Inextensible Comprehension fails too. Observation of 23 September 2026, answering Cian Dorr’s question whether the failure of Actuality can be sharpened to a failure of Inextensible Comprehension. Observation of 23 September 2026, answering Cian Dorr’s question whether the failure of BF sharpens to type $t$. Boolean Completeness fails at type $t$ as well, which the source (n. 92) conjectures but does not show. Observation of Claude Fable 5.1 (Anthropic), 25 September 2026; not in the source.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 3, pp. 74, 77; n. 96; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-monotone-maps.yaml`.

#### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `atomlessness-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `actuality-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-barcan-r`, `inextensible-comprehension-r-implies-weakly-inextensible-comprehension-r`, `vicinity-and-distinctness-preserving-collapse-imply-actuality`.

Model witness ids: `finite-support-monotone-surjections`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
ND fails at the non-injective arrows; BF holds by Proposition D.6 since every arrow is a surjection; Atomlessness holds as in part 1; Boolean Completeness fails at type $e\to t$ because the haecceities of the even numbers have no least upper bound, the strongest persistent property containing them and pinned down by $\{0,\ldots,n\}$ becoming strictly stronger as $n$ grows.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals.
A true $w$ pinned down by a finite set $S$ contains every arrow agreeing with the identity on $S$, among them the monotone surjection equal to the identity up to $M+1$ that sends $M+2$ to $M+1$ and each larger $x$ to $x-1$, for $S\subseteq[0,M]$, one that collapses two individuals $a\ne b$ outside $S$. The proposition that $a$ and $b$ are distinct is true, and it is possible at no arrow that collapses them, since a collapse persists under composition, so $w\not\le\Diamond(a\ne b)$. Observation of Claude Opus 5.5 (Anthropic), 27 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 2, pp. 74, 76–77; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-monotone-surjections.md; Classicism, Definition D.3, footnote 92 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-monotone-surjections.yaml`.

#### Finite-support action model: permutations of N — `finite-support-permutations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `c5-and-completeness-imply-actuality`, `actuality-incompatible-with-atomlessness`, `distinctness-necessary-r-implies-distinctness-necessary-t`, `distinctness-necessary-t-implies-vicinity`, `vicinity-and-weakly-inextensible-comprehension-imply-actuality`, `atomicity-r-implies-atomicity-t`, `atomicity-t-incompatible-with-atomlessness`, `rigid-comprehension-r-implies-actuality`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `atomlessness-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `inextensible-comprehension-r-implies-weakly-inextensible-comprehension-r`.

Model witness ids: `finite-support-permutations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Under it the signature schemata that give the constants a special role fail: with $c\in\Sigma$ of relational type $\tau$, $c=\top_\tau$ necessarily, so Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$, Independence (signature Σ) fails since $c$ denotes what a closed pure term denotes, and Distinctness Maximalism (signature Σ) fails since $c=\top_\tau$ is true and unprovable. But No Contingency (signature Σ), and with it B for sentences of Σ, hold. Boolean Completeness fails here through C5 and the failure of Actuality (Propositions 2.5–2.6), which gives nothing about countable families; but the part 2 argument transfers: the strongest persistent property pinned down by a finite $X$ whose extension contains the even numbers has, at an arrow $h$, the extension $h(X\cap\text{evens})\cup(\mathbb N\setminus hX)$, which strictly shrinks as $X$ grows, so the haecceities of the even numbers have no least upper bound. Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Distinctness-preserving collapse fails: every arrow $h$ has an inverse, so for any true $q$ the arrow $q$-member$\circ h^{-1}$ carries $h$ into $q$, making $\Diamond q$ true everywhere; so $\Box(\Diamond q\to p)$ would need $p=\top$, and the true proposition that $0$ is fixed is not $\top$. Observations of 23 September 2026, answering Cian Dorr’s question whether the failure of Actuality can be sharpened to a failure of Inextensible Comprehension, in the simpler form and with the type-$(t\to t)$ instance of 25 September 2026. Boolean Completeness fails at type $t$ as well, which the source (n. 92) conjectures but does not show. Observation of Claude Fable 5.1 (Anthropic), 25 September 2026; not in the source.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 1, pp. 74–76; p. 79 (No Pure Contingency).

Record: `topics/classicism/models/finite-support-permutations.yaml`.

#### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `rigid-comprehension-r-implies-boolean-completeness-r`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `no-contingency-signature-r-implies-signature-b-r`.

Model witness ids: `finite-support-truncated-shifts`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
All arrows are surjective, so BF holds; $\{k_0\}$ and each $\{k_n\}$ are pinned down by finite sets, so Actuality and Atomicity hold; ND fails; Boolean Completeness fails because the strongest persistent property pinned down by $\{0,\ldots,n\}$ whose extension contains the even numbers has, at $k_m$, the evens, the odds with $0$, or all of $\mathbb N$ according as $m<n$ is even, $m<n$ is odd, or $m\ge n$, and so becomes ever stronger.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals.
Boolean Completeness already fails at type t: the finite/cofinite algebra of arrow indices has no least upper bound for the even-index singleton family.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 8, pp. 74, 78–79; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/finite-support-truncated-shifts.md; Classicism, Definition D.3 and Proposition D.5, pp. 73–79.

Record: `topics/classicism/models/finite-support-truncated-shifts.yaml`.

#### Finite-support action model: truncations of N — `finite-support-truncations`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `atomicity-r-implies-atomicity-t`, `boolean-completeness-r-implies-weakly-inextensible-comprehension-r`, `atomicity-t-and-weakly-inextensible-comprehension-imply-actuality`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `atomicity-and-bf-imply-necessary-actuality`, `necessary-actuality-implies-actuality`, `rigid-comprehension-r-implies-actuality`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-atomicity-r`, `strong-leibniz-t-implies-necessary-actuality`, `inextensible-comprehension-r-implies-weakly-inextensible-comprehension-r`, `atomicity-t-and-bf-t-imply-strong-leibniz-t`, `vicinity-and-distinctness-preserving-collapse-imply-actuality`.

Model witness ids: `finite-support-truncations`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
BF fails since an arrow sending $1$ to $0$ sends everything to $0$; Actuality fails because the strongest true proposition pinned down by $\{0,\ldots,n\}$ is $\{1_{\mathbb N}\}\cup\{g_m:m\ge n\}$, ever stronger as $n$ grows; Atomicity holds because every nonempty proposition contains some $g_n$ and each $\{g_n\}$ is pinned down by a finite set ($\{n-1,n,n+1\}$ for $n>0$, $\{0,1\}$ for $n=0$); Boolean Completeness fails because the strongest persistent property with extension $\mathbb N$ pinned down by $\{0,\ldots,n\}$ becomes ever stronger.
Countable Boolean Completeness fails as well, at type $e\to t$: the property $E$ that the source shows to lack a least upper bound has as its extension a countable family of haecceities, and the extensional fullness the source invokes to put $E$ in the domain also puts in the relation pairing the haecceity of the $k$-th member of that family with the numeral $k$, which injects $E$ into the numerals. Boolean Completeness fails at type $t$ as well, which the source (n. 92) conjectures but does not show. Observation of Claude Fable 5.1 (Anthropic), 23 September 2026, prompted by Cian Dorr; not in the source.
Strong Leibniz-t fails by the nonidentity-idempotent singleton witness in writeups/strong-worlds-one-object-action-models.md. The successor quantifier ranges over all propositions at the target object, including ones outside the transported image. The same write-up gives an explicit finitely pinned BF-t counterexample, also covered by source footnote 92; BF-t and its boxed form now fail under the engine's closure as well.
A true $w$ pinned down by a finite set $S$ contains every arrow agreeing with the identity on $S$, among them the truncation $g_n$ with $n$ above $S$, one that collapses two individuals $a\ne b$ outside $S$. The proposition that $a$ and $b$ are distinct is true, and it is possible at no arrow that collapses them, since a collapse persists under composition, so $w\not\le\Diamond(a\ne b)$. Observation of Claude Opus 5.5 (Anthropic), 27 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, Proposition D.5, part 6, pp. 74, 78; p. 79 (No Pure Contingency).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/finite-support-truncations.yaml`.

#### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `signature-b-and-witnessed-possibility-incompatible`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-possibility-signature-r`, `possibility-signature-r-implies-possibility-schema-r`, `pure-b-and-pure-possibility-incompatible`, `atomicity-t-and-bf-imply-necessary-actuality`, `necessary-actuality-implies-actuality`, `actuality-and-bf-imply-inextensible-comprehension`.

Model witness ids: `finite-support-two-object-all-maps`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Atomlessness fails at $W_0$: the closed sentence that there is exactly one individual denotes the singleton of the unique map to $W_1$, a nonempty proposition with no nonempty proper subproposition.
Distinctness-preserving collapse fails at $W_0$: the transposition of $5$ and $6$ is an arrow with an inverse, so for any true $q$ the composite of a member of $q$ with the inverse carries the transposition into $q$, making $\Diamond q$ true there, while the true proposition that $5$ is fixed is false there. Atomicity fails at $W_0$ already at type $t$. A proposition at $W_0$ is a set of arrows out of $W_0$ whose membership depends on the target and on the values on a finite set; the singleton of the map to $W_1$ is one, and is an atom, but no singleton of a map $\mathbb N\to\mathbb N$ is, since such a map is not determined by finitely many values. So the nonempty proposition of the maps $h\colon\mathbb N\to\mathbb N$ with $h0=0$ has no atom below it: any nonempty subproposition pinned down by $N$ containing $h$ contains all arrows agreeing with $h$ on $N$, and those agreeing with it on $N\cup\{m\}$ form a smaller nonempty one. Actuality fails: the strongest true proposition pinned down by $\{0,\ldots,N\}$ is the set of maps $W_0\to W_0$ agreeing with the identity there, and it strictly shrinks as $N$ grows, so no truth entails every truth; Actual Profile, $\Box$Actuality, Persistent Comprehension and the weak rigid comprehension principles fail with it. Boolean Completeness fails at type $t$: any set $F$ of propositions is the extension of the profile $\langle h,p\rangle\mapsto\{i : i\cdot p\in F\}$, and for $F$ the family of propositions $A_m$ that a map $W_0\to W_0$ is constant on $\{0,\ldots,2m-1\}$ and first changes value at $2m$, the least superset of $\bigcup F$ pinned down by $\{0,\ldots,N\}$, the maps whose first change is at an even position or beyond $N$, strictly shrinks as $N$ grows, so $F$ has no least upper bound. Necessity of Arithmetic nevertheless holds: at $W_0$ the finite cardinalities are the standard numerals and $I^*$ is true; at $W_1$ the numerals remain pairwise distinct, because they differ at the arrows back into $W_0$ and identity is necessary, $I^*$ is again true, the numerals are the finite cardinalities by extensional fullness, and $\operatorname{Sum}$ and $\operatorname{Prod}$ are standard, their graphs being in the domain; so every arithmetical sentence has its standard truth value at every world. $\Box$BF fails already at type $t$: at $W_1$ the arrow $c_n\colon W_1\to W_0$ picking $n$ sends a proposition $q$ to $\{j : c_{j(n)}\in q\}$ (with the arrow to $W_1$ added when $q$ contains $1_{W_1}$), a proposition pinned down by $\{n\}$, so the proposition that $0$ and $1$ are collapsed is in no such image; the profile holding at $\langle h,d\rangle$ iff $h=1_{W_1}$ or $d$ is in the image of $h$, pinned down by $\{0\}$, is necessary of every proposition at $W_1$ but not universal at the world $c_0$. B for pure sentences holds: every world can reach $W_0$ again, by a map $W_0\to W_0$ or by an arrow $c_n$ out of $W_1$, and a closed pure sentence true at $W_0$ is true at every arrow into $W_0$. B for sentences of $\Sigma$ holds under the record's interpretation: a closed $\Sigma$-sentence denotes what $P(d,\ldots,d)$ denotes for a pure $P$ and the individual $d$, and from any world some arrow into $W_0$ carries the current image of $d$ back to $d$, as all maps are arrows. Observations of Claude Fable 5.1 (Anthropic), 25 September 2026; not in the source. Weakly Inextensible Comprehension fails as well: the argument above against Inextensible Comprehension at type $t\to t$ uses only the unboxed matrix of inextensibility at the identity arrow of $W_0$, as the corresponding argument in the permutation model does.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, paragraph beginning “One particularly interesting result”.

Record: `topics/classicism/models/finite-support-two-object-all-maps.yaml`.

#### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `distinctness-necessary-t-implies-modal-five`, `modal-five-implies-modal-b`, `modal-b-implies-distinctness-necessary-r`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-incompatible-with-nd`, `necessary-barcan-r-implies-necessary-barcan-t`, `possibility-and-necessary-barcan-t-incompatible`.

Model witness ids: `full-free-monoid-glued-constants`.

Original record notes:

Promoted from conjectured on 22 September 2026. The gap in the source was its Theorem A.8, stated without proof, and the deferred type-e case; the write-up closes both by choosing a self-similar individual domain and applying the book’s coalesced sums. The signature is assumed countable; for a larger signature use a tree with as many branches. Distinct constants of one type denote distinct entities at the root, since every domain, including the individuals, has more than one element; they are also possibly identical. Everything else follows from the listed principles by the map’s results. Bacon’s interpretation of his predicates Pure and Fun in this model, and the principles stated with them, are not recorded, following Zachary Goodsell’s decision to keep the map to the logical vocabulary and the constants of Σ.
ND and B fail at type t already. Possibility Maximalism (pure) fails because Actuality is necessary while its negation is consistent with C.

- **Logical Combinatorialism** — Andrew Bacon, Logical Combinatorialism, Philosophical Review 129 (2020), Appendix A.2–A.3, pp. 580–587; §2, n. 15, p. 547; §4, n. 48, p. 566.
- **Philosophical Introduction to HOL** — Andrew Bacon, A Philosophical Introduction to Higher-Order Logics, Routledge, 2024, §18.1, Definition 18.1, pp. 391–392; §18.3, Definition 18.6, p. 395; §18.6, Definitions 18.14–18.15, Proposition 18.7, Theorem 18.5 and Exercise 18.23, pp. 405–410.
- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.4–3.5, pp. 55–61 (full action models and the principles they validate); Appendix E, pp. 80–83 (truncations).
- **Fable 22 Sep** — Claude Fable 5.1 (Anthropic), verification of 22 September 2026 (see the write-up).

Record: `topics/classicism/models/full-free-monoid-glued-constants.yaml`.

#### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-pure-contingency-and-nd-t-imply-necessary-nd-t`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `necessary-nd-implies-bf`, `barcan-r-implies-barcan-t`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `axiom-of-infinity-t-implies-infinity-t`, `witnessed-possibility-and-no-pure-contingency-imply-logical-necessity`, `logical-necessity-r-implies-separated-structure-r`, `separated-structure-r-implies-independence-signature-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `no-contingency-signature-r-implies-signature-b-r`.

Model witness ids: `full-idempotent-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
($\{1\}$ is a strong world, its transport along $k$ being empty.) □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, first paragraph; p. 61 (full-model principles).
- **DeepSeek trawl; GPT-6 review 25 Sep** — DeepSeek (deepseek-flash), Classicism theorem trawl, 25 September 2026; mathematically reviewed and corrected by OpenAI Codex (GPT-6), 25 September 2026. Accepted additions only; original construction attribution is unchanged. writeups/strong-worlds-one-object-action-models.md; Classicism, pp. 55–59, 74 and 78; checks/action_strong_worlds.py.

Record: `topics/classicism/models/full-idempotent-monoid.yaml`.

#### Full action model: two-element group — `full-involution-group`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `axiom-of-infinity-t-implies-infinity-t`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `full-involution-group`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Change the two-arrow multiplication to k²=1; evaluate at the sole object.
In a one-object model whose propositions are all the sets of arrows, a singleton $\{h\}$ is a strong world exactly when its transport $\{j : j\circ i=h\}$ along every arrow $i$ has at most one member, since the propositions at that world are again all sets of arrows and a two-element set is split by a singleton. Here the arrows form a group, so $j\circ i=j^{\prime}\circ i$ forces $j=j^{\prime}$. So every singleton is a strong world, every possible proposition contains an arrow, and the type-t Strong Leibniz Biconditionals hold at every world. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, second paragraph; p. 61.

Record: `topics/classicism/models/full-involution-group.yaml`.

#### Full action model: surjections of an infinite set — `full-surjection-monoid`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `no-contingency-signature-incompatible-with-witnessed-possibility`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `signature-b-and-witnessed-possibility-incompatible`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`.

Model witness ids: `full-surjection-monoid`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
Under it the signature schemata that give the constants a special role fail: with $c\in\Sigma$ of relational type $\tau$, $c=\top_\tau$ necessarily, so Witnessed Possibility fails for the pure formula $x\ne\top_\tau$, Separated Structure fails since $\lambda x\, .\,x$ and $\lambda x\, .\,\top_\tau$ agree on $c$, Independence (signature Σ) fails since $c$ denotes what a closed pure term denotes, and Distinctness Maximalism (signature Σ) fails since $c=\top_\tau$ is true and unprovable. But No Contingency (signature Σ), and with it B for sentences of Σ, hold. In a one-object model whose propositions are all the sets of arrows, a singleton $\{h\}$ is a strong world exactly when its transport $\{j : j\circ i=h\}$ along every arrow $i$ has at most one member, since the propositions at that world are again all sets of arrows and a two-element set is split by a singleton. Here every arrow is a surjection, so $j\circ i=j^{\prime}\circ i$ forces $j=j^{\prime}$. So every singleton is a strong world, every possible proposition contains an arrow, and the type-t Strong Leibniz Biconditionals hold at every world. □Relational Choice holds: the truncation of a full action model at any arrow is again a full action model, its domains at the reachable objects being unchanged, and Relational Choice holds in every full model given choice in the metatheory (Classicism, p. 61).

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, third paragraph; p. 61 and n. 84.

Record: `topics/classicism/models/full-surjection-monoid.yaml`.

#### Full action model: two-object chain — `full-two-object-chain`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `fregean-axiom-implies-no-pure-contingency-r`, `axiom-of-infinity-t-implies-infinity-t`, `separated-structure-r-implies-possibly-witnessed-possibility-r`, `possibly-witnessed-possibility-r-implies-witnessed-possibility-r`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-necessary-actuality`, `possible-infinity-t-and-bf-t-imply-axiom-of-infinity-t`.

Model witness ids: `full-two-object-chain`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Whether BF holds at type $e$ depends on the individual domains, which the record does not fix, so the schema is left open.
The type-t Strong Leibniz Biconditionals hold necessarily: at $W_0$ the singleton $\{k\}$ becomes $\{\mathrm{id}_{W_1}\}$ under $k$ and $\{\mathrm{id}_{W_0}\}$ becomes empty, so both singletons are strong worlds; at $W_1$ there is one arrow and one non-bottom proposition. The Strong Leibniz Biconditionals hold at every relational type, necessarily. The arrow $k$ sends a proposition $p\subseteq\{1_{W_0},k\}$ to $\{1_{W_1}\}$ if $k\in p$ and to $\emptyset$ otherwise, so it acts surjectively on the two propositions of $W_1$, which gives the type-$t$ instance at $W_0$; $W_1$ is a one-world model, where BF is trivial. Possible Infinity (type $t$) fails: $W_0$ has four propositions and $W_1$ two, the models being full, so the Axiom of Infinity at type $t$ is false at both worlds. B for pure sentences fails, and B for sentences of $\Sigma$ with it: the pure sentence that there are three pairwise distinct propositions is true at $W_0$ and false at $W_1$, from which no arrow returns. Observations of Claude Fable 5.1 (Anthropic), 25 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fourth paragraph; p. 61.

Record: `topics/classicism/models/full-two-object-chain.yaml`.

#### Full action model: two-object retract — `full-two-object-retract`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `necessary-atomicity-r-implies-atomicity-r`, `necessary-distinctness-necessary-t-implies-necessary-distinctness-necessary-r`, `c5-and-atomicity-imply-no-pure-contingency`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `fregean-axiom-implies-no-pure-contingency-r`.

Model witness ids: `full-two-object-retract`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Only the type-t ND assertion is recorded.
The type-t Strong Leibniz Biconditionals fail at $W_0$: the possible proposition $\{h\}$ has only itself as a candidate strong world below it, but under $h$ it becomes $\{x : x\circ h=h\}=\{\mathrm{id}_{W_1},k\}$, which the proposition $\{\mathrm{id}_{W_1}\}$ of $W_1$’s full domain separates, so $\{h\}$ does not necessarily settle every proposition. Distinctness-preserving collapse fails at $W_0$: let $p:=\{\mathrm{id}_{W_0}\}$, true. A witness $q$ contains $\mathrm{id}_{W_0}$, and $j\circ h=\mathrm{id}_{W_0}$, so $\Diamond q$ holds under $h$ while $p$ does not. The Infinity Schema at type $t$ fails: $W_0$ has exactly four propositions with literal identity, so there are no five pairwise distinct ones; Possible Infinity (type $t$) fails as well, since $W_1$ has eight. Observations of Claude Fable 5.1 (Anthropic), 25 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §3.5, p. 59, fifth paragraph and n. 81; p. 61.

Record: `topics/classicism/models/full-two-object-retract.yaml`.

#### Henkin model: base without a choice function — `henkin-without-relational-choice`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `extensionality-r-implies-fregean-axiom`, `fregean-axiom-implies-no-contingency-signature-r`, `no-contingency-signature-incompatible-with-witnessed-possibility`, `fregean-axiom-implies-necessary-distinctness-necessary-r`, `necessary-distinctness-necessary-r-implies-distinctness-necessary-r`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `extensionality-r-implies-rigid-comprehension-r`, `maximalist-distinctness-incompatible-with-rigid-comprehension`.

Model witness ids: `henkin-without-relational-choice`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References.
The Axiom of Infinity at type $e$ holds, and with it the Infinity Schema and Possible Infinity at that type: a serial relation on a finite set has a functional subrelation in ZF, so the individual domain is infinite, and in the full extensional construction the finite cardinalities are the standard numerals, none of which holds of an infinite universal property. Observation of Claude Fable 5.1 (Anthropic), 25 September 2026.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, §2.3, n. 46, p. 32.

Record: `topics/classicism/models/henkin-without-relational-choice.yaml`.

#### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) — `symmetric-qualitative-contrast`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `c5-and-necessary-actuality-imply-atomicity`, `actuality-implies-persistent-comprehension-r`, `c5-and-persistent-comprehension-imply-gallin`, `gallin-comprehension-implies-nd`, `witnessed-possibility-incompatible-with-nd`, `separated-structure-incompatible-with-nd`, `distinctness-signature-r-implies-distinctness-schema-r`, `maximalist-distinctness-incompatible-with-nd`, `distinctness-preserving-collapse-and-nd-imply-fregean-axiom`, `axiom-of-infinity-t-implies-infinity-t`, `fregean-incompatible-with-infinity-t`, `functional-choice-r-implies-relational-choice-r`.

Model witness ids: `symmetric-qualitative-contrast`.

Original record notes:

The cited construction is a model of the map’s relational-type framework. The description identifies its evaluation point; construction and verification are given at the PDF locations in References. Plenitude still holds by C5 plus Actuality and Propositions 2.5 and 2.14, so this model separates it from Functional Choice even under C5, Rigid Comprehension and Boolean Completeness. This does not settle whether C5 plus Functional Choice implies Atomicity: the model fails the proposed premise.

- **Classicism** — Andrew Bacon and Cian Dorr, Classicism, draft of 16 May 2023, Appendix D, p. 79, final construction (two copies of N).
- **GPT-6 proof 24 Sep** — OpenAI Codex (GPT-6), 24 September 2026. Finite-support transposition proof that Relational Choice and Functional Choice fail at W0, following the user’s suggestion to transfer Plenitude countermodels to Functional Choice; see the accompanying write-up.

Record: `topics/classicism/models/symmetric-qualitative-contrast.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Central questions

Answering a central question settles many other open questions. A question is S ⊢ c, whether S entails c, for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⊢ False asks whether S is inconsistent. "No" denies the entailment, not the conditional. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins classicism`.

### Under no extra assumptions

64 classes and 36 fitting models; 14932 open questions. 77% of questions with up to two premises settled (52199 of 67131).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | (Converse Witnessed Possibility ∧ General Separated Structure) or (Converse Witnessed Possibility ∧ Witnessed Possibility) or (General Separated Structure ∧ Modal Freedom (signature Σ)) or Logical Necessity or (Modal Freedom (signature Σ) ∧ Witnessed Possibility) ⊢ Actual Profile or □Actuality | 289 | 120 |
| 2 | Atomicity ∧ Distinctness Maximalism (signature Σ) ⊢ ⊥ | 95 | 173 |
| 3 | (Converse Witnessed Possibility ∧ General Separated Structure) or (Converse Witnessed Possibility ∧ Witnessed Possibility) or (General Separated Structure ∧ Modal Freedom (signature Σ)) or Logical Necessity or (Modal Freedom (signature Σ) ∧ Witnessed Possibility) ⊢ □Vicinity or Vicinity | 100 | 150 |
| 4 | (Converse Witnessed Possibility ∧ General Separated Structure) or (Converse Witnessed Possibility ∧ Witnessed Possibility) or (General Separated Structure ∧ Modal Freedom (signature Σ)) or Logical Necessity or (Modal Freedom (signature Σ) ∧ Witnessed Possibility) ⊢ □Weakly Inextensible Comprehension or Weakly Inextensible Comprehension | 87 | 193 |
| 5 | Atomicity (type t) ∧ Distinctness Maximalism (signature Σ) ⊢ ⊥ | 188 | 86 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 1735 | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze | 20 | 22 | `strong-possibility-signature-r-implies-strong-possibility-r` |
| 3994 | Boolean Completeness ∧ Relational Choice ⊢ Transversal Choice ★ bronze | 7 | 36 | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| 9575 | Relational Choice ⊢ Transversal Choice ★ bronze | 179 | 1 | `relational-choice-r-implies-transversal-choice-r` |
| 11386 | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze | 84 | 0 | `possible-infinity-t-implies-axiom-of-infinity-t` |
| — | BF ∧ Boolean Completeness ∧ □Atomicity ⊢ Rigid Comprehension ★ bronze  [refuted] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |
| — | Possible Infinity (type e) ⊢ Axiom of Infinity (type e) ★ bronze  [refuted] | — | — | `possible-infinity-e-implies-axiom-of-infinity-e` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | symmetric-infinite-classes: ¬General Separated Structure | 0 | 1294 |
| 2 | symmetric-infinite-classes: ¬Logical Necessity | 0 | 1294 |
| 3 | symmetric-infinite-classes: ¬Witnessed Possibility | 0 | 1294 |
| 4 | Strong Leibniz Biconditionals (type t) ⊬ □BF | 0 | 1252 |
| 5 | Distinctness Maximalism (pure) ⊬ Distinctness-preserving collapse | 0 | 1225 |

### Under C5

37 classes and 9 fitting models; 1243 open questions. 66% of questions with up to two premises settled (2517 of 3760).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | symmetric-qualitative-contrast: □Transversal | 31 | 39 |
| 2 | Independence (signature Σ) ∧ □Functional Choice ⊢ ⊥ | 54 | 25 |
| 3 | (Actual Profile ∧ Relational Choice) or (Actual Profile ∧ Transversal Choice) or Functional Choice ⊢ □Transversal | 32 | 34 |
| 4 | Distinctness-preserving collapse ∧ Independence (signature Σ) ⊢ ⊥ | 27 | 42 |
| 5 | Atomicity ∧ Independence (signature Σ) ⊢ Infinity Schema (type t) | 29 | 33 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 245 | Relational Choice ⊢ Transversal Choice ★ bronze | 63 | 5 | `relational-choice-r-implies-transversal-choice-r` |
| — | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze  [refuted] | — | — | `strong-possibility-signature-r-implies-strong-possibility-r` |
| — | Actual Profile ∧ Relational Choice ⊢ Transversal Choice ★ bronze  [proved] | — | — | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| — | Atomicity ⊢ Actual Profile ★ bronze  [proved] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ ⊥ | 0 | 433 |
| 2 | ⊤ ⊬ □Transversal | 0 | 311 |
| 3 | Independence (signature Σ) ⊬ Distinctness-preserving collapse | 1 | 292 |
| 4 | Independence (signature Σ) ∧ Necessity of Arithmetic ⊬ ⊥ | 1 | 288 |
| 5 | Independence (signature Σ) ⊬ □Functional Choice | 1 | 273 |

### Under C5 + Atomicity

24 classes and 6 fitting models; 115 open questions. 62% of questions with up to two premises settled (190 of 305).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Distinctness-preserving collapse ∧ Independence (signature Σ) ⊢ ⊥ | 9 | 9 |
| 2 | Independence (signature Σ) ∧ No Contingency (signature Σ) ⊢ Infinity Schema (type t) | 10 | 8 |
| 3 | Independence (signature Σ) ∧ Modal Freedom (signature Σ) ⊢ Infinity Schema (type t) | 11 | 5 |
| 4 | Independence (signature Σ) ∧ No Contingency (signature Σ) ⊢ Axiom of Infinity (type t) | 11 | 5 |
| 5 | Axiom of Infinity (type e) ∧ Independence (signature Σ) ⊢ Distinctness-preserving collapse | 6 | 5 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze  [refuted] | — | — | `strong-possibility-signature-r-implies-strong-possibility-r` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ ⊥ | 0 | 63 |
| 2 | Independence (signature Σ) ⊬ Distinctness-preserving collapse | 1 | 39 |
| 3 | Independence (signature Σ) ∧ Modal Freedom (signature Σ) ⊬ ⊥ | 1 | 34 |
| 4 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊬ ⊥ | 1 | 28 |
| 5 | Independence (signature Σ) ∧ Infinity Schema (type t) ⊬ ⊥ | 2 | 24 |

### Under Extensionalism

22 classes and 3 fitting models; 14 open questions. 79% of questions with up to two premises settled (53 of 67).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | Axiom of Infinity (type e) ∧ Independence (signature Σ) ⊢ ⊥ | 4 | 2 |
| 2 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊢ ⊥ | 8 | 1 |
| 3 | Functional Choice ∧ Independence (signature Σ) ⊢ ⊥ | 5 | 1 |
| 4 | Independence (signature Σ) ⊢ Axiom of Infinity (type e) | 4 | 1 |
| 5 | Functional Choice ∧ Independence (signature Σ) ⊢ Axiom of Infinity (type e) | 1 | 3 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze  [refuted] | — | — | `strong-possibility-signature-r-implies-strong-possibility-r` |
| — | Possible Infinity (type t) ⊢ Axiom of Infinity (type t) ★ bronze  [proved] | — | — | `possible-infinity-t-implies-axiom-of-infinity-t` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Independence (signature Σ) ⊬ ⊥ | 0 | 11 |
| 2 | Independence (signature Σ) ∧ Infinity Schema (type e) ⊬ ⊥ | 1 | 8 |
| 3 | Functional Choice ∧ Independence (signature Σ) ⊬ ⊥ | 1 | 5 |
| 4 | Axiom of Infinity (type e) ∧ Independence (signature Σ) ⊢ Functional Choice | 0 | 5 |
| 5 | Functional Choice ∧ Independence (signature Σ) ⊢ Infinity Schema (type e) | 0 | 5 |

### Under Pure Maximalist Classicism

72 classes and 3 fitting models; 5488 open questions. 23% of questions with up to two premises settled (1701 of 7189).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | coalesced-single-individual-root: Distinctness Maximalism (signature Σ) | 62 | 49 |
| 2 | BF ∧ Strong Possibility (signature Σ) ⊢ ⊥ | 53 | 43 |
| 3 | Actual Profile ∧ Strong Possibility (signature Σ) ⊢ ⊥ | 76 | 32 |
| 4 | Atomicity ∧ □Weakly Inextensible Comprehension ⊢ ⊥ | 55 | 35 |
| 5 | BF ∧ Distinctness Maximalism (signature Σ) ⊢ Distinctness-preserving collapse | 61 | 32 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 1343 | Strong Possibility (signature Σ) ⊢ Strong Possibility (pure) ★ bronze | 20 | 6 | `strong-possibility-signature-r-implies-strong-possibility-r` |
| 1444 | Relational Choice ⊢ Transversal Choice ★ bronze | 43 | 5 | `relational-choice-r-implies-transversal-choice-r` |
| — | BF ∧ Boolean Completeness ∧ □Atomicity ⊢ Rigid Comprehension ★ bronze  [incompatible] | — | — | `necessary-atomicity-completeness-bf-imply-rigid-comprehension` |
| — | Boolean Completeness ∧ Relational Choice ⊢ Transversal Choice ★ bronze  [incompatible] | — | — | `relational-choice-and-boolean-completeness-imply-transversal-choice` |
| — | ⊤ ⊢ Axiom of Infinity (type e) ★ bronze  [refuted] | — | — | `possible-infinity-e-implies-axiom-of-infinity-e` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | ⊤ ⊬ Distinctness-preserving collapse | 0 | 1767 |
| 2 | ⊤ ⊬ Actual Profile | 0 | 1541 |
| 3 | BF (type t) ⊬ ⊥ | 0 | 1142 |
| 4 | Atomicity (type t) ⊬ ⊥ | 0 | 1083 |
| 5 | Independence (signature Σ) ⊬ Distinctness-preserving collapse | 1 | 866 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### C5

Assuming `necessary-distinctness-necessary-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal (`transversal-r`)

### C5 + Atomicity

Assuming `necessary-distinctness-necessary-r`, `atomicity-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Pure Maximalist Classicism

Assuming `distinctness-schema-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Distinctness Maximalism (signature Σ) (`distinctness-signature-r`)
- General Separated Structure (`general-separated-structure-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possibility Maximalism (signature Σ) (`possibility-signature-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Actuality + BF

Assuming `actuality`, `barcan-r`, these remain open:

- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Boolean Completeness + Actuality

Assuming `boolean-completeness-r`, `actuality`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)

### □BF + Actuality

Assuming `necessary-barcan-r`, `actuality`, these remain open:

- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □ND + Actuality

Assuming `necessary-distinctness-necessary-r`, `actuality`, these remain open:

- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + Actuality

Assuming `no-pure-contingency-r`, `actuality`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Atomicity + BF

Assuming `atomicity-r`, `barcan-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + Atomicity

Assuming `no-pure-contingency-r`, `atomicity-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Atomicity (type t) + BF

Assuming `atomicity-t`, `barcan-r`, these remain open:

- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### Atomicity (type t) + BF (type t)

Assuming `atomicity-t`, `barcan-t`, these remain open:

- Atomicity (`atomicity-r`)
- BF (`barcan-r`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### □ND + Atomicity (type t)

Assuming `necessary-distinctness-necessary-r`, `atomicity-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Atomicity (type t) + Weakly Inextensible Comprehension

Assuming `atomicity-t`, `weakly-inextensible-comprehension-r`, these remain open:

- Atomicity (`atomicity-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)

### ND + BF

Assuming `distinctness-necessary-r`, `barcan-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal (`transversal-r`)

### Gallin Extensional Comprehension + BF

Assuming `gallin-extensional-comprehension-r`, `barcan-r`, these remain open:

- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + BF

Assuming `no-pure-contingency-r`, `barcan-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + BF

Assuming `possible-infinity-e`, `barcan-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Transversal (`transversal-r`)

### Rigid Comprehension + BF

Assuming `rigid-comprehension-r`, `barcan-r`, these remain open:

- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)

### No Pure Contingency + BF (type t)

Assuming `no-pure-contingency-r`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- Functionality (`functionality-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### Possible Infinity (type t) + BF (type t)

Assuming `possible-infinity-t`, `barcan-t`, these remain open:

- BF (`barcan-r`)
- Functionality (`functionality-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Tractarianism (`tractarianism-r`)

### □ND + Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `boolean-completeness-r`, these remain open:

- □Transversal (`necessary-transversal-r`)

### No Pure Contingency + Boolean Completeness

Assuming `no-pure-contingency-r`, `boolean-completeness-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + ND

Assuming `no-pure-contingency-r`, `distinctness-necessary-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Rigid Comprehension + ND

Assuming `rigid-comprehension-r`, `distinctness-necessary-r`, these remain open:

- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)

### No Pure Contingency + ND (type t)

Assuming `no-pure-contingency-r`, `distinctness-necessary-t`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Distinctness Maximalism (pure) + Separated Structure

Assuming `distinctness-schema-r`, `separated-structure-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type e) (`infinity-e`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Relational Choice (`relational-choice-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Vicinity (`vicinity`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### No Pure Contingency + Functional Choice

Assuming `no-pure-contingency-r`, `functional-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Functionality

Assuming `no-pure-contingency-r`, `functionality-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Gallin Extensional Comprehension

Assuming `no-pure-contingency-r`, `gallin-extensional-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + B

Assuming `no-pure-contingency-r`, `modal-b`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + 5

Assuming `no-pure-contingency-r`, `modal-five`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### □ND + □Actuality

Assuming `necessary-distinctness-necessary-r`, `necessary-actuality`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Atomicity + □BF

Assuming `necessary-atomicity-r`, `necessary-barcan-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Atomicity + □BF (type t)

Assuming `necessary-atomicity-r`, `necessary-barcan-t`, these remain open:

- BF (`barcan-r`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### □Strong Leibniz Biconditionals (type t) + □BF

Assuming `necessary-strong-leibniz-t`, `necessary-barcan-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □ND + □Boolean Completeness

Assuming `necessary-distinctness-necessary-r`, `necessary-boolean-completeness-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + □Rigid Comprehension

Assuming `necessary-distinctness-necessary-r`, `necessary-rigid-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □ND + Persistent Comprehension

Assuming `necessary-distinctness-necessary-r`, `persistent-comprehension-r`, these remain open:

- □Transversal (`necessary-transversal-r`)

### □Relational Choice + □Plenitude

Assuming `necessary-relational-choice-r`, `necessary-plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### □Transversal + □Relational Choice

Assuming `necessary-transversal-r`, `necessary-relational-choice-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### □Strong Leibniz Biconditionals + Rigid Comprehension

Assuming `necessary-strong-leibniz-r`, `rigid-comprehension-r`, these remain open:

- BF (`barcan-r`)
- Functionality (`functionality-r`)
- □BF (`necessary-barcan-r`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### □Vicinity + □Weakly Inextensible Comprehension

Assuming `necessary-vicinity`, `necessary-weakly-inextensible-comprehension-r`, these remain open:

- Necessity of Arithmetic (`necessity-of-arithmetic`)

### No Pure Contingency + Plenitude

Assuming `no-pure-contingency-r`, `plenitude-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Possible Infinity (type e) + No Pure Contingency

Assuming `possible-infinity-e`, `no-pure-contingency-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### Possible Infinity (type t) + No Pure Contingency

Assuming `possible-infinity-t`, `no-pure-contingency-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Relational Choice

Assuming `no-pure-contingency-r`, `relational-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + Rigid Comprehension

Assuming `no-pure-contingency-r`, `rigid-comprehension-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Strong Leibniz Biconditionals

Assuming `no-pure-contingency-r`, `strong-leibniz-r`, these remain open:

- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Tractarianism (`tractarianism-r`)

### No Pure Contingency + Strong Leibniz Biconditionals (type t)

Assuming `no-pure-contingency-r`, `strong-leibniz-t`, these remain open:

- Atomicity (`atomicity-r`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Functionality (`necessary-functionality-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Tractarianism (`tractarianism-r`)

### No Pure Contingency + Tractarianism

Assuming `no-pure-contingency-r`, `tractarianism-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Transversal Choice

Assuming `no-pure-contingency-r`, `transversal-choice-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Transversal

Assuming `no-pure-contingency-r`, `transversal-r`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### No Pure Contingency + Vicinity

Assuming `no-pure-contingency-r`, `vicinity`, these remain open:

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- Transversal (`transversal-r`)

### No Pure Contingency + Weakly Inextensible Comprehension

Assuming `no-pure-contingency-r`, `weakly-inextensible-comprehension-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Witnessed Possibility + No Pure Contingency

Assuming `witnessed-possibility-r`, `no-pure-contingency-r`, these remain open:

- Actual Profile (`actual-profile-r`)
- Actuality (`actuality`)
- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Functionality (`functionality-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- Infinity Schema (type t) (`infinity-t`)
- □Actuality (`necessary-actuality`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (`necessary-barcan-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Functionality (`necessary-functionality-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Tractarianism (`necessary-tractarianism-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- □Weakly Inextensible Comprehension (`necessary-weakly-inextensible-comprehension-r`)
- Persistent Comprehension (`persistent-comprehension-r`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Relational Choice (`relational-choice-r`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Tractarianism (`tractarianism-r`)
- Transversal Choice (`transversal-choice-r`)
- Transversal (`transversal-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Vicinity (`vicinity`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Weakly Inextensible Comprehension (`weakly-inextensible-comprehension-r`)

### Relational Choice + Plenitude

Assuming `relational-choice-r`, `plenitude-r`, these remain open:

- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- Rigid Comprehension (`rigid-comprehension-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)

### Relational Choice + Very Weak Rigid Comprehension

Assuming `relational-choice-r`, `very-weak-rigid-comprehension-r`, these remain open:

- Inextensible Comprehension (`inextensible-comprehension-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- □Vicinity (`necessary-vicinity`)
- Rigid Comprehension (`rigid-comprehension-r`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Coalesced sum: root over all finite individual domains — `coalesced-all-finite-individual-domains`

Fully determined; nothing unknown.

### Coalesced sum: root individuals indexed by infinitely many individual constants — `coalesced-constant-indexed-root`

Fully determined; nothing unknown.

### Coalesced sum: maximalist root — `coalesced-maximalist-root`

Fully determined; nothing unknown.

### Coalesced sum: singleton individual root — `coalesced-single-individual-root`

- Distinctness Maximalism (signature Σ) (`distinctness-signature-r`)
- General Separated Structure (`general-separated-structure-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Possibility+ (signature Σ) (`possibility-plus-signature-r`)
- Possibility Maximalism (signature Σ) (`possibility-signature-r`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Separated Structure (`separated-structure-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: dyadic roundings of N — `finite-support-dyadic-roundings`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: identity-or-collapse monotone surjections — `finite-support-identity-or-collapse-surjections`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: identity-or-collapse monotone maps — `finite-support-identity-or-collapse`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: monotone maps of N — `finite-support-monotone-maps`

- Independence (signature Σ) (`independence-signature-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: monotone surjections of N — `finite-support-monotone-surjections`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: permutations of N — `finite-support-permutations`

Fully determined; nothing unknown.

### Finite-support action model: N and N×2, sections and projection — `finite-support-sections-and-projection`

- Atomicity (`atomicity-r`)
- Atomicity (type t) (`atomicity-t`)
- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- BF (type t) (`barcan-t`)
- Boolean Completeness (`boolean-completeness-r`)
- Boolean Completeness (type t) (`boolean-completeness-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Countable Boolean Completeness (`countable-boolean-completeness-r`)
- ND (`distinctness-necessary-r`)
- ND (type t) (`distinctness-necessary-t`)
- Functional Choice (`functional-choice-r`)
- Gallin Extensional Comprehension (`gallin-extensional-comprehension-r`)
- General Separated Structure (`general-separated-structure-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Logical Necessity (`logical-necessity-r`)
- B (`modal-b`)
- 5 (`modal-five`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Atomicity (`necessary-atomicity-r`)
- □BF (type t) (`necessary-barcan-t`)
- □Boolean Completeness (`necessary-boolean-completeness-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Strong Leibniz Biconditionals (`necessary-strong-leibniz-r`)
- □Strong Leibniz Biconditionals (type t) (`necessary-strong-leibniz-t`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- Necessity of Arithmetic (`necessity-of-arithmetic`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Plenitude (`plenitude-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Strong Leibniz Biconditionals (`strong-leibniz-r`)
- Strong Leibniz Biconditionals (type t) (`strong-leibniz-t`)
- Transversal Choice (`transversal-choice-r`)
- Very Weak Rigid Comprehension (`very-weak-rigid-comprehension-r`)
- Weak Rigid Comprehension (`weak-rigid-comprehension-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Finite-support action model: truncated shifts of N — `finite-support-truncated-shifts`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Finite-support action model: truncations of N — `finite-support-truncations`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- B for sentences of Σ (`signature-b-r`)

### Finite-support action model: N and singleton, all maps — `finite-support-two-object-all-maps`

- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)

### Full Boolean-valued model: one atom and an atomless component — `full-boolean-valued-atom-and-atomless`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- □Transversal (`necessary-transversal-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)

### Full action model: free monoid on countably many generators, glued constants, singleton individuals — `full-free-monoid-glued-constants-singleton`

Fully determined; nothing unknown.

### Full action model: free monoid on countably many generators, glued constants, thread individuals — `full-free-monoid-glued-constants`

Fully determined; nothing unknown.

### Full Henkin model: countably infinite individual domain — `full-henkin-infinite-base`

Fully determined; nothing unknown.

### Full Henkin model: singleton individual domain — `full-henkin-singleton-base`

Fully determined; nothing unknown.

### Full action model: idempotent two-arrow monoid — `full-idempotent-monoid`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Infinity Schema (type e) (`infinity-e`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Full action model: two-element group — `full-involution-group`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Infinity Schema (type e) (`infinity-e`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Full action model: permutations of an infinite set — `full-permutation-group-infinite-set`

Fully determined; nothing unknown.

### Full action model: permutations of an infinite set, one individual — `full-permutation-group-one-individual`

Fully determined; nothing unknown.

### Full action model: surjections of an infinite set — `full-surjection-monoid`

Fully determined; nothing unknown.

### Full action model: two-object chain — `full-two-object-chain`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- BF (`barcan-r`)
- Functionality (`functionality-r`)
- Infinity Schema (type e) (`infinity-e`)
- □BF (`necessary-barcan-r`)
- □Functionality (`necessary-functionality-r`)
- □Tractarianism (`necessary-tractarianism-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Tractarianism (`tractarianism-r`)

### Full action model: two-object retract — `full-two-object-retract`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Infinity Schema (type e) (`infinity-e`)
- Possible Infinity (type e) (`possible-infinity-e`)

### Henkin model: base without a choice function — `henkin-without-relational-choice`

Fully determined; nothing unknown.

### Symmetric ideally-full model: all surjections of N (Base 1) — `symmetric-all-surjections`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)

### Symmetric ideally-full model: permutations and collapsers of a fixed pair (Base 2) — `symmetric-collapse-pair`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetric ideally-full model: automorphisms of infinitely many infinite classes — `symmetric-infinite-classes`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- General Separated Structure (`general-separated-structure-r`)
- Independence (signature Σ) (`independence-signature-r`)
- Infinity Schema (type e) (`infinity-e`)
- Logical Necessity (`logical-necessity-r`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possibly Witnessed Possibility (`possibly-witnessed-possibility-r`)
- Separated Structure (`separated-structure-r`)
- B for sentences of Σ (`signature-b-r`)
- Witnessed Possibility (`witnessed-possibility-r`)

### Symmetric ideally-full model: qualitative contrast (Appendix D precursor) — `symmetric-qualitative-contrast`

- □Transversal (`necessary-transversal-r`)

### Symmetric ideally-full model: qualitative link structure (Base 3) — `symmetric-qualitative-links`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)

### Symmetric ideally-full model: arrows omitting or reserving a fixed individual — `symmetric-range-gap-without-actuality`

- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Transversal (`necessary-transversal-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- B for sentences of Σ (`signature-b-r`)
- Transversal (`transversal-r`)

### Symmetric ideally-full model: arrows omitting a fixed individual — `symmetric-range-gap`

- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Rigid Comprehension (`necessary-rigid-comprehension-r`)
- Rigid Comprehension (`rigid-comprehension-r`)

### Symmetric ideally-full model: two objects, the second unpinned — `symmetric-two-object-unpinned`

- BF (`barcan-r`)
- BF (type t) (`barcan-t`)
- Functionality (`functionality-r`)
- □BF (type t) (`necessary-barcan-t`)
- Tractarianism (`tractarianism-r`)

### Action model: a fork with an ultralimit world — `ultralimit-fork`

- Axiom of Infinity (type e) (`axiom-of-infinity-e`)
- Axiom of Infinity (type t) (`axiom-of-infinity-t`)
- Converse Witnessed Possibility (`converse-witnessed-possibility-r`)
- Distinctness-preserving collapse (`distinctness-preserving-collapse`)
- Infinity Schema (type e) (`infinity-e`)
- Infinity Schema (type t) (`infinity-t`)
- Modal Freedom (signature Σ) (`modal-freedom-signature-r`)
- □Relational Choice (`necessary-relational-choice-r`)
- □Transversal Choice (`necessary-transversal-choice-r`)
- No Contingency (signature Σ) (`no-contingency-signature-r`)
- No Pure Contingency (`no-pure-contingency-r`)
- Possible Infinity (type e) (`possible-infinity-e`)
- Possible Infinity (type t) (`possible-infinity-t`)
- B for pure sentences (`pure-b-r`)
- Relational Choice (`relational-choice-r`)
- B for sentences of Σ (`signature-b-r`)
- Transversal Choice (`transversal-choice-r`)

## 5. Open single-premise pairs (492)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **5** (`modal-five`) ⇒ Necessity of Arithmetic, Transversal, □Transversal, □Vicinity
- **Atomicity** (`atomicity-r`) ⇒ Necessity of Arithmetic, Transversal, □Atomicity, □Transversal
- **Atomicity (type t)** (`atomicity-t`) ⇒ Atomicity, Necessity of Arithmetic, Transversal, □Atomicity, □Transversal
- **Atomlessness** (`atomlessness`) ⇒ Axiom of Infinity (type e), B for pure sentences, B for sentences of Σ, Converse Witnessed Possibility, Infinity Schema (type e), Modal Freedom (signature Σ), Necessity of Arithmetic, No Pure Contingency, Possible Infinity (type e)
- **Axiom of Infinity (type e)** (`axiom-of-infinity-e`) ⇒ Transversal
- **B** (`modal-b`) ⇒ Necessity of Arithmetic, Transversal, □Transversal, □Vicinity
- **B for pure sentences** (`pure-b-r`) ⇒ Necessity of Arithmetic
- **B for sentences of Σ** (`signature-b-r`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **BF** (`barcan-r`) ⇒ Necessity of Arithmetic
- **BF (type t)** (`barcan-t`) ⇒ BF, Functionality, Necessity of Arithmetic, Tractarianism
- **Boolean Completeness** (`boolean-completeness-r`) ⇒ Inextensible Comprehension
- **Boolean Completeness (type t)** (`boolean-completeness-t`) ⇒ Boolean Completeness, Countable Boolean Completeness, Inextensible Comprehension, Necessity of Arithmetic, Weakly Inextensible Comprehension
- **Converse Witnessed Possibility** (`converse-witnessed-possibility-r`) ⇒ Modal Freedom (signature Σ)
- **Countable Boolean Completeness** (`countable-boolean-completeness-r`) ⇒ Boolean Completeness, Boolean Completeness (type t), Inextensible Comprehension, Weakly Inextensible Comprehension
- **Distinctness Maximalism (pure)** (`distinctness-schema-r`) ⇒ Actual Profile, Actuality, Distinctness Maximalism (signature Σ), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Persistent Comprehension, Possibility Maximalism (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Witnessed Possibility
- **Distinctness Maximalism (signature Σ)** (`distinctness-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **Distinctness-preserving collapse** (`distinctness-preserving-collapse`) ⇒ Transversal
- **Functional Choice** (`functional-choice-r`) ⇒ Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Gallin Extensional Comprehension, Inextensible Comprehension, Necessity of Arithmetic, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Relational Choice, □Transversal, □Transversal Choice, □Vicinity
- **Functionality** (`functionality-r`) ⇒ Necessity of Arithmetic
- **Gallin Extensional Comprehension** (`gallin-extensional-comprehension-r`) ⇒ Actual Profile, Actuality, Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Inextensible Comprehension, Necessity of Arithmetic, Persistent Comprehension, Plenitude, Rigid Comprehension, Transversal, Very Weak Rigid Comprehension, Weak Rigid Comprehension, Weakly Inextensible Comprehension, □Transversal, □Vicinity
- **General Separated Structure** (`general-separated-structure-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **Independence (signature Σ)** (`independence-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, General Separated Structure, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Witnessed Possibility
- **Infinity Schema (type e)** (`infinity-e`) ⇒ Axiom of Infinity (type e), Possible Infinity (type e), Transversal
- **Infinity Schema (type t)** (`infinity-t`) ⇒ Axiom of Infinity (type t), Possible Infinity (type t)
- **Logical Necessity** (`logical-necessity-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Axiom of Infinity (type t), BF, BF (type t), Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Distinctness-preserving collapse, Functionality, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Rigid Comprehension, Strong Leibniz Biconditionals, Strong Leibniz Biconditionals (type t), Tractarianism, Transversal, Transversal Choice, Very Weak Rigid Comprehension, Vicinity, Weak Rigid Comprehension, Weakly Inextensible Comprehension, □Actuality, □Atomicity, □BF, □BF (type t), □Boolean Completeness, □Functionality, □Relational Choice, □Rigid Comprehension, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t), □Tractarianism, □Transversal, □Transversal Choice, □Vicinity, □Weakly Inextensible Comprehension
- **Modal Freedom (signature Σ)** (`modal-freedom-signature-r`) ⇒ BF, BF (type t), Functionality, Tractarianism, Transversal, □BF, □BF (type t), □Functionality, □Tractarianism, □Transversal
- **ND** (`distinctness-necessary-r`) ⇒ Necessity of Arithmetic, Transversal, □Transversal, □Vicinity
- **ND (type t)** (`distinctness-necessary-t`) ⇒ Necessity of Arithmetic, Transversal, □Transversal, □Vicinity
- **No Contingency (signature Σ)** (`no-contingency-signature-r`) ⇒ BF, BF (type t), Functionality, Tractarianism, Transversal, □BF, □BF (type t), □Functionality, □Tractarianism, □Transversal
- **No Pure Contingency** (`no-pure-contingency-r`) ⇒ Modal Freedom (signature Σ)
- **Plenitude** (`plenitude-r`) ⇒ Boolean Completeness, Boolean Completeness (type t), Countable Boolean Completeness, Gallin Extensional Comprehension, Inextensible Comprehension, Necessity of Arithmetic, Rigid Comprehension, Very Weak Rigid Comprehension, Weak Rigid Comprehension, □Transversal, □Vicinity
- **Possibility Maximalism (pure)** (`possibility-schema-r`) ⇒ Actual Profile, Actuality, Distinctness Maximalism (signature Σ), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Persistent Comprehension, Possibility Maximalism (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Witnessed Possibility
- **Possibility Maximalism (signature Σ)** (`possibility-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **Possibility+ (pure)** (`possibility-plus-r`) ⇒ Actual Profile, Actuality, Distinctness Maximalism (signature Σ), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Persistent Comprehension, Possibility Maximalism (signature Σ), Possibility+ (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Witnessed Possibility
- **Possibility+ (signature Σ)** (`possibility-plus-signature-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type e), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **Possible Infinity (type e)** (`possible-infinity-e`) ⇒ Transversal
- **Possible Infinity (type t)** (`possible-infinity-t`) ⇒ Axiom of Infinity (type t), Infinity Schema (type t)
- **Possibly Witnessed Possibility** (`possibly-witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **Relational Choice** (`relational-choice-r`) ⇒ Transversal, Transversal Choice
- **Rigid Comprehension** (`rigid-comprehension-r`) ⇒ □Transversal, □Vicinity
- **Separated Structure** (`separated-structure-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Relational Choice, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **Strong Leibniz Biconditionals** (`strong-leibniz-r`) ⇒ BF, BF (type t), Functionality, Inextensible Comprehension, Necessity of Arithmetic, Tractarianism, □Atomicity, □BF, □BF (type t), □Functionality, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t), □Tractarianism
- **Strong Leibniz Biconditionals (type t)** (`strong-leibniz-t`) ⇒ Atomicity, BF, BF (type t), Functionality, Inextensible Comprehension, Necessity of Arithmetic, Strong Leibniz Biconditionals, Tractarianism, □Atomicity, □BF, □BF (type t), □Functionality, □Strong Leibniz Biconditionals, □Strong Leibniz Biconditionals (type t), □Tractarianism
- **Strong Possibility (pure)** (`strong-possibility-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), BF, BF (type t), Boolean Completeness (type t), Distinctness Maximalism (signature Σ), Functionality, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility Maximalism (signature Σ), Possibility+ (pure), Possibility+ (signature Σ), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Strong Possibility (signature Σ), Tractarianism, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, Witnessed Possibility, □Transversal, □Vicinity, □Weakly Inextensible Comprehension
- **Strong Possibility (signature Σ)** (`strong-possibility-signature-r`) ⇒ Actual Profile, Actuality, Atomicity, Atomicity (type t), Atomlessness, Axiom of Infinity (type e), BF, BF (type t), Boolean Completeness (type t), Functionality, Inextensible Comprehension, Infinity Schema (type e), Persistent Comprehension, Possibility+ (pure), Possibility+ (signature Σ), Relational Choice, Strong Possibility (pure), Tractarianism, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension, □Transversal, □Vicinity, □Weakly Inextensible Comprehension
- **Tractarianism** (`tractarianism-r`) ⇒ Necessity of Arithmetic
- **Very Weak Rigid Comprehension** (`very-weak-rigid-comprehension-r`) ⇒ Inextensible Comprehension, □Transversal, □Vicinity
- **Vicinity** (`vicinity`) ⇒ Transversal
- **Weak Rigid Comprehension** (`weak-rigid-comprehension-r`) ⇒ Inextensible Comprehension, □Transversal, □Vicinity
- **Witnessed Possibility** (`witnessed-possibility-r`) ⇒ Actual Profile, Actuality, Axiom of Infinity (type t), Distinctness-preserving collapse, General Separated Structure, Independence (signature Σ), Inextensible Comprehension, Infinity Schema (type t), Persistent Comprehension, Possible Infinity (type t), Possibly Witnessed Possibility, Relational Choice, Separated Structure, Transversal, Transversal Choice, Vicinity, Weakly Inextensible Comprehension
- **□5** (`necessary-modal-five`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Actuality** (`necessary-actuality`) ⇒ Necessity of Arithmetic
- **□Atomicity** (`necessary-atomicity-r`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□B** (`necessary-modal-b`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□BF** (`necessary-barcan-r`) ⇒ Necessity of Arithmetic
- **□BF (type t)** (`necessary-barcan-t`) ⇒ BF, Functionality, Necessity of Arithmetic, Tractarianism, □BF, □Functionality, □Tractarianism
- **□Boolean Completeness** (`necessary-boolean-completeness-r`) ⇒ Inextensible Comprehension, □Weakly Inextensible Comprehension
- **□Functional Choice** (`necessary-functional-choice-r`) ⇒ Modal Freedom (signature Σ)
- **□Functionality** (`necessary-functionality-r`) ⇒ Necessity of Arithmetic
- **□Gallin Extensional Comprehension** (`necessary-gallin-extensional-comprehension-r`) ⇒ Modal Freedom (signature Σ)
- **□ND** (`necessary-distinctness-necessary-r`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□ND (type t)** (`necessary-distinctness-necessary-t`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Plenitude** (`necessary-plenitude-r`) ⇒ Modal Freedom (signature Σ)
- **□Relational Choice** (`necessary-relational-choice-r`) ⇒ Necessity of Arithmetic, Transversal, Transversal Choice, □Transversal, □Transversal Choice
- **□Strong Leibniz Biconditionals** (`necessary-strong-leibniz-r`) ⇒ BF, BF (type t), Functionality, Inextensible Comprehension, Necessity of Arithmetic, Tractarianism, □BF, □BF (type t), □Functionality, □Tractarianism
- **□Strong Leibniz Biconditionals (type t)** (`necessary-strong-leibniz-t`) ⇒ Atomicity, BF, BF (type t), Functionality, Inextensible Comprehension, Necessity of Arithmetic, Strong Leibniz Biconditionals, Tractarianism, □Atomicity, □BF, □BF (type t), □Functionality, □Strong Leibniz Biconditionals, □Tractarianism
- **□Tractarianism** (`necessary-tractarianism-r`) ⇒ Necessity of Arithmetic
- **□Transversal** (`necessary-transversal-r`) ⇒ Necessity of Arithmetic
- **□Transversal Choice** (`necessary-transversal-choice-r`) ⇒ Necessity of Arithmetic
- **□Vicinity** (`necessary-vicinity`) ⇒ Necessity of Arithmetic, Transversal, □Transversal
- **□Weakly Inextensible Comprehension** (`necessary-weakly-inextensible-comprehension-r`) ⇒ Necessity of Arithmetic

## 6. Deliberately deferred

`topics/classicism/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/classicism/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/classicism/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Worked on a question without settling it? Put what you tried and what would settle it in the conjecture's `notes`; that alone earns it a bronze lynchpin star. Say in the notes whether you think it deserves silver or gold, by importance and difficulty, and why. Only a human sets `tier: silver` or `tier: gold`; an agent never does.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
