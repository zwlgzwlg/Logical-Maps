# Open questions — Unbounded Utility

Conjectures, their current answers, and remaining gaps where a new result or model would contribute to the map.

**"Open" means not settled by the records in this bundle.** It does not mean unsolved in the literature, and it does not mean hard. Many entries below are routine and simply have not been added yet. Check the sources before assuming a question is new.

## 1. Conjectures and their answers

Answers below are recomputed from proved records under the fixed topic background. A conjectured record supplies no evidence for its own answer. Records marked was_conjectured remain in this history after promotion to proved; their proved status, rather than the historical marker, determines whether they supply evidence. Original sources and notes are retained below each answer.

### 1.1 Unresolved (3)

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Stochastic Dominance ∧ Mixture Independence ∧ Comonotonic Sum Invariance ⇒ Scale Invariance — `conjectured-dtu-comonotonic-imply-scale`

**Answer: Open.**

Original record notes:

Does DTU with Comonotonic Sum Invariance give Scale Invariance for every real factor? Under these premises Shift Invariance (comonotonic-sum-implies-shift) and Rational Scale Invariance (comonotonic-sum-totality-imply-rational-scale) are proved, so the conclusion is equivalent to Positive Affine Invariance (shift-scale-imply-positive-affine) and only irrational factors are at issue. In quantile coordinates the order is a ℚ-cone of width functions Q_X − Q_Y and dilation by a is multiplication by a; in survival coordinates Mixture Independence makes it a convex ℝ-cone and dilation is the substitution t ↦ t/a. Rational dilations preserve the cone; an irrational one is a limit of rational ones, and the question is whether the cone is closed enough for the limit to pass. What would settle it: a proof, which must use Mixture Independence, because lexicographic-hamel-tie-break satisfies every other premise, Simple EU included, and violates the conclusion; or a model of DTU with Comonotonic Sum Invariance that fails Scale Invariance, which would also show that package consistent, something no recorded model does (conjectured-total-comonotonic-area-extension). A continuity assumption closes the gap on bounded gambles only: for |X|, |Y| ≤ M and rational q within ε/M of a, Stochastic Dominance gives aX ≽ qX − ε and qY ≽ aY − ε, so aX + 2ε ≽ aY whenever X ≽ Y, and Continuity under Vanishing Shifts removes the shift; unbounded gambles do not admit this sandwich. Proposed tier: none; a human may set one.

- **Goodsell question 24 Sep** — Zachary Goodsell, Logical Maps session, 24 September 2026: claim that Comonotonic Sum Invariance implies Positive Affine Invariance, with the passage from rational to real factors left open.
- **Claude formulation 24 Sep** — Claude (Fable 5.1), Logical Maps, 24 September 2026: precise DTU formulation, and the two models showing which premises the rational-factor proof cannot spare; see writeups/lexicographic-hamel-tie-break.md.

Record: `topics/unbounded-utility/results/conjectured-dtu-comonotonic-imply-scale.yaml`.

#### Rich Outcomes ∧ Archimedean Outcomes ∧ Stochastic Equivalence ∧ Stochastic Dominance ∧ Mixture Independence ∧ Comonotonic Sum Invariance ⇒ Rational Affine Preservation — `conjectured-du-comonotonic-imply-rational-affine-preservation`

**Answer: Open.**

Original record notes:

Does DU with Comonotonic Sum Invariance preserve weak and strict comparisons under every map aX + b with rational a > 0? The integer factors are proved from Rich Outcomes, Stochastic Equivalence and Comonotonic Sum Invariance alone (comonotonic-sum-implies-integer-affine-preservation), so what is open is the factor 1/n, and X ≽ Y ⇒ X/n ≽ Y/n is the cancellation nX′ ≽ nY′ ⇒ X′ ≽ Y′. Cancellation holds with Totality (comonotonic-sum-totality-imply-rational-scale) and fails without Mixture Independence: cdf-area-unit-threshold satisfies Rich Outcomes, Archimedean Outcomes, Stochastic Equivalence, Stochastic Dominance, Simple EU and Comonotonic Sum Invariance, has X* ≽ 0 with X*/2 ⋡ 0, and satisfies Integer Affine Preservation. What would settle it: a proof, which must use Mixture Independence; or a DU model with Comonotonic Sum Invariance in which some nX ≽ nY holds with X ⋡ Y. Under DU with Stochastic Equivalence the order is determined by the width h = Q_X − Q_Y, every pair whose width is bounded below with positive integral is strictly ranked (a step function below the width with positive integral is the width of a simple comonotonic pair, and the shear is comonotonic), and every pair with a step-function width is ranked by its integral; a refuting pair must therefore have equal finite areas, a width unbounded below, or both areas infinite, and its closure under mixtures and comonotonic shears must stay consistent with strict dominance. Proposed tier: none; a human may set one.

- **Goodsell claim 24 Sep** — Zachary Goodsell, Logical Maps session, 24 September 2026: claim that under DU Comonotonic Sum Invariance preserves weak and strict order under positive rational affine maps.
- **Claude reduction 24 Sep** — Claude (Fable 5.1), Logical Maps, 24 September 2026: the integer case comonotonic-sum-implies-integer-affine-preservation and the reduction of the remainder to integer cancellation; the unit-threshold model shows Mixture Independence is needed.

Record: `topics/unbounded-utility/results/conjectured-du-comonotonic-imply-rational-affine-preservation.yaml`.

#### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

**Answer: Open.**

Original record notes:

Original work: precise candidate formulation and comparison of two extension problems. The base area construction, its comonotonic property, and the broader unresolved consistency question are credited to Goodsell. The manuscript's Theorem 7 supplies only the incomplete area model, not this proposed total CDF-area extension. No new completed model is claimed. To settle positively, give a total extension and verify that adjoining comparisons preserves every old strict area comparison, full Mixture Independence, and comonotonic preservation and cancellation. To settle negatively, derive an incompatibility from the displayed package. A generic order extension is insufficient, and the total convolution model is not evidence that comonotonic invariance survives. No claim is made that the question is open in the literature.
Progress (Claude, Fable 5.1, 23 September 2026; write-up section “A necessary condition: forced comparisons of both-infinite pairs”): a killing lemma shows that under Stochastic Equivalence, Stochastic Dominance, Mixture Independence and comonotonic preservation alone, X ≽ Y fails whenever comonotonic shears of the survival difference combine with positive weights into a nonpositive nonzero profile; an explicit both-infinite pair is killed, so the extension must rank it Y ≻ X where the area is silent. Prefix positivity, a positive lowest block, or divergent prefix sums certify that a pair is not killed; for prefix-oscillating block regions the sign of the lowest block is forced. An accounting heuristic suggests that no pair is killed in both orientations, so the lemma alone will not refute the package. Every clipped-expectation model in this topic violates Comonotonic Sum Invariance (half-Cauchy common summand), so the extension cannot come from clipped areas, and probability-trimmed quantile means are comonotonic invariant but not mixture-linear. Candidate: the area when defined, else a functional of the level-ordered block surplus, completed by Zorn's lemma over cones closed under both additive structures with the killing lemma as the pointedness test; regions with no lowest block are where a refutation would have to be sought. Tier set to silver by Zachary Goodsell, 23 September 2026.

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, §3, pp. 7–8, and discussion before Theorem 7 and Theorem 7, pp. 19–20: CDF-area construction, its comonotonic invariance, and the broader unresolved consistency question.
- **GPT-6 conjecture 9 Sep** — GPT-6 (Codex), 9 September 2026, proposed total-extension package and obstacle analysis in writeups/conjectured-total-comonotonic-area-extension.md.
- **Claude killing lemma 23 Sep** — Claude (Fable 5.1), Logical Maps, 23 September 2026: killing lemma and an explicit forced comparison, section “A necessary condition: forced comparisons of both-infinite pairs” of the write-up; diagnostic checks/comonotonic_witnesses.py.

Record: `topics/unbounded-utility/models/conjectured-total-comonotonic-area-extension.yaml`.

### 1.2 Resolved (6)

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Independent Sum Cancellation ⇒ Independent Sum Preservation — `conjectured-dtu-cancellation-implies-preservation`

**Answer: Proved.**

Supporting result ids: `conjectured-dtu-cancellation-implies-preservation`.

Original record notes:

The original seven-premise conjecture is proved without changing its statement; was_conjectured preserves its history. The geometric renewal law closes the earlier indifference gap. The existing proof with L1 Continuity remains valid but its extra premise is unnecessary. Under DTU, Cancellation, Preservation and Independent Sum Invariance are equivalent by this theorem and the existing converse deductions. Arbitrary independent noise is essential to the argument: the geometric auxiliary law generally has infinite support. No full-noise property is thereby established for the finite-shift total extension. Original connecting work under Misc.; no literature-priority claim, independent checker or Lean verification is asserted.

- **GPT-6 conjecture 9 Sep; proof 13 Sep** — GPT-6 (Codex), 9 September 2026: original conjecture and partial analysis; 13 September 2026: geometric-noise proof in writeups/conjectured-dtu-cancellation-implies-preservation.md.
- **Goodsell argument 13 Sep** — Zachary Goodsell, project conversation, 13 September 2026: request to resolve Cancellation implies Preservation and the contraposition argument for strict comparisons.
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, unpublished manuscript, 5 June 2026, Lemma 1, pp. 7–8: source for the separated sum principles, not this connecting theorem.

Record: `topics/unbounded-utility/results/conjectured-dtu-cancellation-implies-preservation.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Shift Invariance ⇒ Transfer of a Shift Across a Mixture — `conjectured-dtu-shift-implies-transfer`

**Answer: Refuted.**

Model witness ids: `finite-shift-total-extension`.

Original record notes:

Original work: conjecture formulation and partial analysis, with a separately recorded countermodel added on 13 September 2026. The candidate asks whether DTU plus Shift Invariance alone implies Shift Transfer, equivalently under DTU Simple Relative Expectation. The recorded neutrality-shift-imply-shift-transfer proof settles the question after adding Symmetric Neutrality. The du-vanishing-shifts-imply-relative proof settles it after adding Continuity under Vanishing Shifts; under DU this is equivalent to L1 Continuity. The independent du-l1-implies-relative proof also supplies the continuity route, without Totality or Shift Invariance. Consequently a separating model would have to fail both neutrality and L1 Continuity. The continuous clipping models already satisfy Relative Expectation; the new lexicographic folded-tail model fails continuity but still satisfies Relative Expectation and neutrality. Neither family supplies the required separation. The new finite-support-compensated-dominance model does separate DU plus Shift Invariance from Shift Transfer, but it violates Totality and therefore does not settle this DTU conjecture. Its explicit transfer and vanishing-shift continuity failures are proved in its write-up. Its finite-shift-total-extension now supplies Totality while strictly ordering the same transfer pair. The new proof checks finite-kernel saturation and preserves the indifferent subspace through the orientation and maximal-extension steps. The original implication, ID, empty proof and conjectured status remain unchanged: the viewer computes refutation from this separate proved model. Stronger backgrounds can still prove the conditional implication, and source filters can remove its refuting evidence. Conjectured records question history, not a claim that the current full evidence leaves it open.

- **GPT-6 question 9 Sep** — GPT-6 (Codex), 9 September 2026, follow-up DU investigation; precise unresolved implication and partial analysis in writeups/conjectured-dtu-shift-implies-transfer.md.
- **Symmetries of Value** — Zachary Goodsell, Symmetries of value, Noûs 60 (2026), 16–37, DOI 10.1111/nous.12549, Theorems 3–4, pp. 25–27: source for Shift Transfer and its derivation with full affine symmetry, not this conjecture.
- **Goodsell/GPT-6 countermodel 13 Sep** — Zachary Goodsell (finite-shift extension proposal) and GPT-6 (Codex) (countermodel and extension proof), Logical Maps, 13 September 2026: the separately recorded model finite-shift-total-extension refutes this implication under its stated premises; see writeups/finite-shift-total-extension.md.

Record: `topics/unbounded-utility/results/conjectured-dtu-shift-implies-transfer.yaml`.

#### Countable Sure-Thing ∧ Archimedean Outcomes ⇒ Archimedean Gambles — `countable-sure-thing-outcomes-to-gambles`

**Answer: Refuted.**

Model witness ids: `lexicographic-nonatomic-mass`.

Original record notes:

Refuted on the standing full measurable domain by the proved lexicographic-nonatomic-mass model, supplied by GPT-6 (Codex) on 13 September 2026. It satisfies both proposed premises, as well as Totality, Stochastic Equivalence, Stochastic Dominance, Mixture Independence and Sure-Thing, while violating both Expected Utility and Archimedean Gambles. Its outcome chart is [0,1], so Rich Outcomes fails; that principle is not a premise of this question. The Russell–Isaacs theorem concerns countably supported lotteries: its domain excludes the nonatomic witness used here. The original ID, premises, authorship and conjectured status are preserved. Refutation is computed from the separate proved model and selected background; under DU or DTU the premises instead conflict with the background. See the handwritten write-up for the witness and source comparison. No independent checking or Lean proof is claimed.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Infinite Prospects (domain comparison)** — Related discrete-lottery theorem, not a theorem of this full-domain arrow: Jeffrey Sanford Russell and Yoaav Isaacs, Infinite Prospects, Philosophy and Phenomenological Research 103 (2021), 178–198, DOI 10.1111/phpr.12704. Author-hosted manuscript, §§4–5 and Appendix A, especially pp. 15, 22, 25: https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: full-domain refutation in writeups/lexicographic-nonatomic-mass.md and source comparison in writeups/countable-sure-thing-outcomes-to-gambles.md.

Record: `topics/unbounded-utility/results/countable-sure-thing-outcomes-to-gambles.yaml`.

#### Countable Sure-Thing ∧ Simple Expected Utility ⇒ Expected Utility — `countable-sure-thing-simple-to-full-eu`

**Answer: Refuted.**

Model witness ids: `lexicographic-nonatomic-mass`.

Original record notes:

Refuted on the standing full measurable domain by the proved lexicographic-nonatomic-mass model, supplied by GPT-6 (Codex) on 13 September 2026. It satisfies both proposed premises, as well as Totality, Stochastic Equivalence, Stochastic Dominance, Mixture Independence and Sure-Thing, while violating both Expected Utility and Archimedean Gambles. Its outcome chart is [0,1], so Rich Outcomes fails; that principle is not a premise of this question. The Russell–Isaacs theorem concerns countably supported lotteries: its domain excludes the nonatomic witness used here. The original ID, premises, authorship and conjectured status are preserved. Refutation is computed from the separate proved model and selected background; under DU or DTU the premises instead conflict with the background. See the handwritten write-up for the witness and source comparison. No independent checking or Lean proof is claimed.

- **User suggestion 8 Sep** — User suggestion in this project's conversation, 2026-09-08; proposed implication, not a completed proof.
- **Decision Theory Unbound** — Related motivation rather than a verified theorem with these exact premises: Goodsell, Decision theory unbound, Noûs 58 (2024), 669–695, DOI 10.1111/nous.12473, §4.1, pp. 685–686.
- **GPT-6 countermodel 13 Sep** — GPT-6 (Codex), Logical Maps, 13 September 2026: full-domain refutation in writeups/lexicographic-nonatomic-mass.md and source comparison in writeups/countable-sure-thing-simple-to-full-eu.md.

Record: `topics/unbounded-utility/results/countable-sure-thing-simple-to-full-eu.yaml`.

#### Rich Outcomes ∧ Totality ∧ Stochastic Equivalence ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Mixture Independence ∧ Symmetric Gambles Are Neutral ∧ Independent Sum Invariance ⇒ ⊥ — `symmetric-dtu-refutes-independent-sum-candidate`

**Answer: Proved.**

Supporting result ids: `independent-sum-implies-preservation`, `levy-refutes-neutral-independent-preservation`.

Original record notes:

Settled 9 September 2026 by levy-refutes-neutral-independent-preservation. Original work: direct consequence of that proof completion; no additional mathematical construction is needed for this larger premise package. Goodsell’s proposal and the historical source audit are preserved. The previous open-status wording below records the state before completion.

Historical notes:
Records the user’s proposed incompatibility with a deliberately sufficient package. The user recalls balanced mixtures involving stable indices 1 and 1/2, neutral by symmetry, becoming strictly dominance-ordered after convolution by a common index-1/2 law. Exact laws, skewness, scale, location, mixture weights, and a global strict-dominance proof remain to be specified. The draft explicitly withdraws its symmetry lemma; that proof failure alone is not a proof of this implication. Excluded from proved inference and known-inconsistency warnings.

Representation update: the former negative conclusion is expressed by adding independent-sum-consistency to the premises and concluding False. The mathematical claim, source, and proof are unchanged.

- **Goodsell proposal 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: revised conjecture omitting reflection and recollection of a stable-distribution obstruction
- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026, unpublished manuscript marked “do not cite” and erroneous; §4, pp. 10–14 (withdrawn consistency argument)
- **GPT-6 proof completion 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/levy-refutes-neutral-independent-preservation.md: complete reduced-premise proof of Goodsell’s stable-law obstruction.

Record: `topics/unbounded-utility/results/symmetric-dtu-refutes-independent-sum-candidate.yaml`.

#### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

**Answer: Existence witnessed.**

A proved model meets the recorded satisfies/violates requirements. This witnesses their consistency, not necessarily the proposed construction.

Supporting result ids: `dominance-refutes-full-sum`, `dominance-refutes-antitonic-sum`, `independence-to-sure-thing`, `rich-simple-sure-thing-refutes-countable`, `dtu-refutes-archimedean-gambles`.

Model witness ids: `conjectured-total-independent-sum-extension`.

Original record notes:

The construction, conclosure operation, and total-extension strategy are attributed to Zachary Goodsell and his unpublished manuscript. GPT-6 supplied the cone-language exposition and additional proof details in the write-up; these are not attributed verbatim to the manuscript, and no independently originated AI construction is claimed. Upgraded from conjectured after those details were recorded; the stable ID is retained. Neither reflection requirement is assumed or listed as violated. The raw area cone’s cancellation remains unasserted: conclosure can enlarge it. This is nonconstructive existence using Zorn’s lemma. No independent checker or Lean verification is claimed.

- **Unbounded Utility and Background Risk (unpublished)** — Zachary Goodsell, Unbounded Utility and Background Risk, 5 June 2026 (unpublished), §§3–4, pp. 7–14: CDF-area construction, conclosure, and total-extension strategy. Supplied manuscript marked “do not cite” and erroneous in its symmetry-extension claim.
- **GPT-6 proof details 9 Sep** — GPT-6 (Codex), 9 September 2026, writeups/conjectured-total-independent-sum-extension.md: cone-language exposition of Goodsell’s conclosure and additional details establishing strictness preservation and the total-extension step; not an independently originated construction.
- **Goodsell clarification 9 Sep** — Zachary Goodsell, project conversation, 9 September 2026: extension without reflection and clarification that the saturation construction is conclosure.

Record: `topics/unbounded-utility/models/conjectured-total-independent-sum-extension.yaml`.

### 1.3 Incompatible with background (0)

None.

## 2. Central questions

Answering a central question settles many other open questions. A question is S ⊢ c, whether S entails c, for S at most two principle classes (True, with none) and c a class or False, asked only where no smaller premise set already proves or excludes c; S ⊢ False asks whether S is inconsistent. "No" denies the entailment, not the conditional. A question is settled alike by a proof, by an exclusion (S ∧ c ⇒ False) or by a recorded model that holds S and fails c. Each row scores an open question by the number of *other* open questions that stop being open once the answer joins the proved records. Both answers are scored, because proving a strong conjecture settles everything below it while refuting a weak one settles everything above it; a question with two high scores is worth answering either way. A refutation is scored by its least informative countermodel, so an actual model settles at least as much. A model check (model: principle) scores deciding an unknown verdict inside a recorded model, which settles questions exactly as a proof does. Under a background, only models of that background count and the class of its theorems is named after it (True, with no preset). Recompute with `python3 scripts/pmap.py lynchpins unbounded-utility`.

### Under no extra assumptions

43 classes and 17 fitting models; 19405 open questions. 45% of questions with up to two premises settled (15999 of 35404).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | cdf-area-preorder: Independent Sum Cancellation | 334 | 158 |
| 2 | cdf-area-preorder: Independent Sum Invariance | 334 | 158 |
| 3 | affine-symmetric-extension: Existential Copula Sum Invariance | 141 | 219 |
| 4 | cdf-conclosure-preorder: Uniqueness of Negative Self-Similarity (integer ratios) | 273 | 100 |
| 5 | CDF-Area Extension ∧ Universal Copula Sum Invariance ⊢ ⊥ | 116 | 153 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| — | CDF-Area Extension ∧ Comonotonic Sum Invariance ∧ Mixture Independence ∧ Rich Outcomes ∧ Totality ⊬ ⊥ ★ silver  [more than two premises] | — | — | `conjectured-total-comonotonic-area-extension` |
| — | Archimedean Outcomes ∧ Comonotonic Sum Invariance ∧ Mixture Independence ∧ Rich Outcomes ∧ Stochastic Dominance ⊢ Rational Affine Preservation ★ bronze  [more than two premises] | — | — | `conjectured-du-comonotonic-imply-rational-affine-preservation` |
| — | Archimedean Outcomes ∧ Comonotonic Sum Invariance ∧ Mixture Independence ∧ Rich Outcomes ∧ Stochastic Dominance ∧ Totality ⊢ Scale Invariance ★ bronze  [more than two premises] | — | — | `conjectured-dtu-comonotonic-imply-scale` |
| — | Mixture Independence ∧ Rich Outcomes ∧ Shift Invariance ∧ Simple Expected Utility ∧ Stochastic Dominance ∧ Totality ⊢ Transfer of a Shift Across a Mixture ★ bronze  [more than two premises] | — | — | `conjectured-dtu-shift-implies-transfer` |
| — | Archimedean Outcomes ∧ Countable Sure-Thing ⊢ Archimedean Gambles ★ bronze  [refuted] | — | — | `countable-sure-thing-outcomes-to-gambles` |
| — | Countable Sure-Thing ∧ Simple Expected Utility ⊢ Expected Utility ★ bronze  [refuted] | — | — | `countable-sure-thing-simple-to-full-eu` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Antitonic Sum Invariance ⊬ ⊥ | 0 | 4211 |
| 2 | Comonotonic Sum Invariance ∧ Independent Sum Cancellation ⊬ ⊥ | 0 | 3033 |
| 3 | Comonotonic Sum Invariance ∧ Independent Sum Invariance ⊬ ⊥ | 1 | 2972 |
| 4 | Antitonic Sum Invariance ∧ Existential Copula Sum Invariance ⊬ ⊥ | 1 | 2894 |
| 5 | Antitonic Sum Invariance ∧ Independent Sum Cancellation ⊬ ⊥ | 1 | 2780 |

### Under DU

31 classes and 13 fitting models; 3637 open questions. 39% of questions with up to two premises settled (2351 of 5988).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | affine-symmetric-extension: Comonotonic Sum Invariance | 124 | 117 |
| 2 | cdf-area-preorder: Independent Sum Cancellation | 157 | 76 |
| 3 | cdf-area-preorder: Independent Sum Invariance | 157 | 76 |
| 4 | affine-symmetric-extension: Existential Copula Sum Invariance | 63 | 267 |
| 5 | conjectured-total-independent-sum-extension: Rational Scale Invariance | 69 | 100 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 557 | Comonotonic Sum Invariance ⊢ Rational Affine Preservation ★ bronze | 15 | 23 | `conjectured-du-comonotonic-imply-rational-affine-preservation` |
| 3105 | Comonotonic Sum Invariance ∧ Totality ⊢ Scale Invariance ★ bronze | 1 | 56 | `conjectured-dtu-comonotonic-imply-scale` |
| — | CDF-Area Extension ∧ Comonotonic Sum Invariance ∧ Totality ⊬ ⊥ ★ silver  [more than two premises] | — | — | `conjectured-total-comonotonic-area-extension` |
| — | Countable Sure-Thing ⊢ Archimedean Gambles ★ bronze  [refuted] | — | — | `countable-sure-thing-outcomes-to-gambles` |
| — | Countable Sure-Thing ⊢ Expected Utility ★ bronze  [refuted] | — | — | `countable-sure-thing-simple-to-full-eu` |
| — | Shift Invariance ∧ Totality ⊢ Transfer of a Shift Across a Mixture ★ bronze  [refuted] | — | — | `conjectured-dtu-shift-implies-transfer` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Alternating St Petersburg = −1/2 ⊬ Folded Expectation | 0 | 663 |
| 2 | Existential Copula Sum Invariance ⊬ Independent Sum Invariance | 0 | 632 |
| 3 | Integer Affine Preservation ⊬ Negative Affine Anti-Invariance | 0 | 627 |
| 4 | Alternating St Petersburg = −1/2 ∧ Existential Copula Sum Invariance ⊬ ⊥ | 0 | 608 |
| 5 | Existential Copula Sum Invariance ∧ Integer Affine Preservation ⊬ Independent Sum Invariance | 1 | 558 |

### Under DTU

27 classes and 9 fitting models; 2438 open questions. 22% of questions with up to two premises settled (709 of 3147).

Central questions, by the harmonic mean of what either answer would settle: the questions worth working on, since one that only matters if it comes out the implausible way sinks.

| Rank | Question | if yes | if no |
|---:|---|---:|---:|
| 1 | CDF-Area Extension ∧ Negative Affine Anti-Invariance ⊢ Comonotonic Sum Invariance | 65 | 113 |
| 2 | Folded Expectation ∧ Negative Affine Anti-Invariance ⊢ Comonotonic Sum Invariance | 65 | 113 |
| 3 | Folded Expectation ∧ Positive Affine Invariance ⊢ Comonotonic Sum Invariance | 65 | 113 |
| 4 | Folded Expectation ∧ Scale Invariance ⊢ Comonotonic Sum Invariance | 65 | 113 |
| 5 | L¹ Continuity (random variables) ∧ Negative Affine Anti-Invariance ⊢ Comonotonic Sum Invariance | 65 | 113 |

Conjectures, each as the question it asks, in the same format: ⊢ claims the entailment and ⊬ denies it, and if yes / if no are what confirming or refuting the conjecture would settle. A settled conjecture shows its verdict and no rank or scores; one with more than two premises is marked. ★ bronze for notes, silver or gold where a record ranks it by importance and difficulty.

| Rank | Conjecture | if yes | if no | record |
|---:|---|---:|---:|---|
| 179 | Comonotonic Sum Invariance ⊢ Scale Invariance ★ bronze | 30 | 41 | `conjectured-dtu-comonotonic-imply-scale` |
| 1093 | CDF-Area Extension ∧ Comonotonic Sum Invariance ⊬ ⊥ ★ silver | 6 | 193 | `conjectured-total-comonotonic-area-extension` |
| — | Countable Sure-Thing ⊢ Archimedean Gambles ★ bronze  [refuted] | — | — | `countable-sure-thing-outcomes-to-gambles` |
| — | Countable Sure-Thing ⊢ Expected Utility ★ bronze  [refuted] | — | — | `countable-sure-thing-simple-to-full-eu` |
| — | Comonotonic Sum Invariance ⊢ Rational Affine Preservation ★ bronze  [proved] | — | — | `conjectured-du-comonotonic-imply-rational-affine-preservation` |
| — | Shift Invariance ⊢ Transfer of a Shift Across a Mixture ★ bronze  [refuted] | — | — | `conjectured-dtu-shift-implies-transfer` |

Automatically generated conjectures: questions ranked by how many questions would be settled by a negative result.

| “If no” rank | Conjecture | if yes | if no |
|---:|---|---:|---:|
| 1 | Integer Affine Preservation ⊬ Folded Expectation | 0 | 788 |
| 2 | Existential Copula Sum Invariance ∧ Integer Affine Preservation ⊬ ⊥ | 0 | 751 |
| 3 | Rational Scale Invariance ⊬ Folded Expectation | 0 | 728 |
| 4 | Integer Affine Preservation ⊬ Negative Affine Anti-Invariance | 0 | 724 |
| 5 | Existential Copula Sum Invariance ∧ Rational Affine Preservation ⊬ ⊥ | 1 | 706 |

## 3. Open questions under each recorded package

The most useful place to work: these are open *given* assumptions the sources already make.

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `l1-continuity`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance + Relative Expectation

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, `relative-expectation`, these remain open:

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Independent Sum Cancellation

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Expected Utility (`expected-utility`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `l1-continuity`, these remain open:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Stochastic Dominance + Mixture Independence + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `stochastic-dominance`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Stochastic Dominance + Mixture Independence + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, `l1-continuity`, these remain open:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Stochastic Dominance + Mixture Independence + Continuity under Vanishing Shifts

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `stochastic-dominance`, `independence`, `vanishing-shift-continuity`, these remain open:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Expected Utility + Stochastic Equivalence + Mixture Independence + Stochastic Dominance + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `expected-utility`, `stochastic-equivalence`, `independence`, `stochastic-dominance`, `l1-continuity`, these remain open:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Rich Outcomes + Totality + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Reflection Anti-Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `simple-eu`, `independence`, `reflection-anti-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- Pasadena = ln 2 (`pasadena-value`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Symmetric Gambles Are Neutral + Shift Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `symmetric-neutrality`, `shift-invariance`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Totality (`totality`)

### Rich Outcomes + Totality + Mixture Independence + Integer Affine Preservation + Reflection Anti-Invariance

Assuming `rich-outcomes`, `totality`, `independence`, `integer-affine-preservation`, `reflection-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Stochastic Equivalence + Mixture Independence + Relative Expectation + Uniqueness of Negative Self-Similarity (integer ratios)

Assuming `rich-outcomes`, `stochastic-equivalence`, `independence`, `relative-expectation`, `integer-negative-self-similarity`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Scale Invariance (`scale-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Stochastic Equivalence + Mixture Independence + Relative Expectation + Uniqueness of Negative Self-Similarity

Assuming `rich-outcomes`, `stochastic-equivalence`, `independence`, `relative-expectation`, `negative-self-similarity`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Scale Invariance (`scale-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Mixture Independence + Transfer of a Shift Across a Mixture

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `independence`, `shift-transfer`, these remain open:

- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Relative Expectation (`relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Totality + Stochastic Equivalence + Mixture Independence + Symmetric Gambles Are Neutral

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `independence`, `symmetric-neutrality`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Pasadena = ln 2 (`pasadena-value`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Totality + Stochastic Dominance + L¹ Continuity (random variables) + Independent Sum Cancellation

Assuming `rich-outcomes`, `totality`, `stochastic-dominance`, `l1-continuity`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Gambles (`archimedean-gambles`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)

### Rich Outcomes + Stochastic Equivalence + Relative Expectation + Symmetric Gambles Are Neutral + Shift Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `relative-expectation`, `symmetric-neutrality`, `shift-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Dominance + Relative Expectation

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-dominance`, `relative-expectation`, these remain open:

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Shift Invariance (`shift-invariance`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Archimedean Outcomes + Stochastic Equivalence + Statewise Dominance

Assuming `rich-outcomes`, `archimedean-outcomes`, `stochastic-equivalence`, `statewise-dominance`, these remain open:

- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)

### Rich Outcomes + Totality + Stochastic Equivalence + Comonotonic Sum Invariance

Assuming `rich-outcomes`, `totality`, `stochastic-equivalence`, `comonotonic-sum-consistency`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- Countable Sure-Thing (`countable-sure-thing`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Uniqueness of Negative Self-Similarity (integer ratios)

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `integer-negative-self-similarity`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- Integer Affine Preservation (`integer-affine-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Stochastic Equivalence + Simple Expected Utility + Uniqueness of Negative Self-Similarity

Assuming `rich-outcomes`, `stochastic-equivalence`, `simple-eu`, `negative-self-similarity`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Mixture Independence (`independence`)
- Integer Affine Preservation (`integer-affine-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Stochastic Equivalence + Comonotonic Sum Invariance

Assuming `rich-outcomes`, `stochastic-equivalence`, `comonotonic-sum-consistency`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Restricted Totality (`restricted-totality`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Mixture Independence + Folded Expectation

Assuming `rich-outcomes`, `independence`, `folded-expectation`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Totality + Mixture Independence + Negative Affine Anti-Invariance

Assuming `totality`, `independence`, `negative-affine-anti-invariance`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Simple Relative Expectation + L¹ Continuity (random variables)

Assuming `rich-outcomes`, `simple-relative-expectation`, `l1-continuity`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Positive Affine Invariance + Reflection Anti-Invariance

Assuming `rich-outcomes`, `positive-affine-invariance`, `reflection-anti-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Rational Scale Invariance + Shift Invariance

Assuming `rich-outcomes`, `rational-scale-invariance`, `shift-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)

### Rich Outcomes + Relative Expectation + Continuity under Vanishing Shifts

Assuming `rich-outcomes`, `relative-expectation`, `vanishing-shift-continuity`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Rich Outcomes + Shift Invariance + Scale Invariance

Assuming `rich-outcomes`, `shift-invariance`, `scale-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Mixture Independence (`independence`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Antitonic Sum Invariance + Stochastic Equivalence

Assuming `antitonic-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Gambles (`archimedean-gambles`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Expected Utility (`expected-utility`)
- Folded Expectation (`folded-expectation`)
- Full Sum Invariance (`full-sum-consistency`)
- Mixture Independence (`independence`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Archimedean Outcomes + Folded Expectation

Assuming `archimedean-outcomes`, `folded-expectation`, these remain open:

- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Totality (`totality`)

### Archimedean Outcomes + Relative Expectation

Assuming `archimedean-outcomes`, `relative-expectation`, these remain open:

- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Mixture Independence (`independence`)
- Rich Outcomes (`rich-outcomes`)
- Shift Invariance (`shift-invariance`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Archimedean Outcomes + Stochastic Dominance

Assuming `archimedean-outcomes`, `stochastic-dominance`, these remain open:

- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)

### Comonotonic Sum Invariance + Stochastic Equivalence

Assuming `comonotonic-sum-consistency`, `stochastic-equivalence`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Rich Outcomes + Folded Expectation

Assuming `rich-outcomes`, `folded-expectation`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Pasadena = ln 2 (`pasadena-value`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Totality (`totality`)

### Mixture Independence + Transfer of a Shift Across a Mixture

Assuming `independence`, `shift-transfer`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

### Stochastic Equivalence + Mixture Independence

Assuming `stochastic-equivalence`, `independence`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)

### Independent Sum Preservation + Independent Sum Cancellation

Assuming `independent-sum-preservation`, `independent-sum-cancellation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Independent Sum Invariance + Stochastic Equivalence

Assuming `independent-sum-consistency`, `stochastic-equivalence`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Totality (`restricted-totality`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Totality + Independent Sum Preservation

Assuming `totality`, `independent-sum-preservation`, these remain open:

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Archimedean Outcomes (`archimedean-outcomes`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Expected Utility (`expected-utility`)
- Mixture Independence (`independence`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Relative Expectation (`relative-expectation`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Rich Outcomes (`rich-outcomes`)
- Scale Invariance (`scale-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Expected Utility (`simple-eu`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Rich Outcomes + Negative Affine Anti-Invariance

Assuming `rich-outcomes`, `negative-affine-anti-invariance`, these remain open:

- Archimedean Outcomes (`archimedean-outcomes`)
- Mixture Independence (`independence`)
- Restricted Stochastic Equivalence (`restricted-stochastic-equivalence`)
- Restricted Totality (`restricted-totality`)
- Simple Expected Utility (`simple-eu`)
- Statewise Dominance (`statewise-dominance`)
- Stochastic Dominance (`stochastic-dominance`)
- Stochastic Equivalence (`stochastic-equivalence`)
- Sure-Thing (`sure-thing`)

## 4. Unknown verdicts inside each model

For these principles the model has not been checked either way. Deciding one is a self-contained calculation in a construction that is already written down.

### Signed-measure cone: affine-symmetric extension — `affine-symmetric-extension`

- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)

### Clipped expectation: continuous ultrafilter dominance [−t, 2t] — `asymmetric-continuous-ultrafilter`

- Arroyo = ln 2 (`arroyo-value`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Scale Invariance (`scale-invariance`)

### CDF-area dominance — `cdf-area-preorder`

- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)

### CDF-area dominance: simple floors or unit threshold — `cdf-area-unit-threshold`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Countable Sure-Thing (`countable-sure-thing`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)

### CDF-area conclosure — `cdf-conclosure-preorder`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### CDF-area: total comonotonic extension — `conjectured-total-comonotonic-area-extension`

Fully determined; nothing unknown.

### CDF-area conclosure: total extension — `conjectured-total-independent-sum-extension`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Scale Invariance (`scale-invariance`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Clipped expectation: eventual dominance — `eventual-clipped-expectation`

- Arroyo = ln 2 (`arroyo-value`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Pasadena = ln 2 (`pasadena-value`)
- Rational Affine Preservation (`rational-affine-preservation`)

### Stochastic dominance: finite-shift total extension — `finite-shift-total-extension`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Scale Invariance (`scale-invariance`)

### Stochastic dominance: finite-support compensation — `finite-support-compensated-dominance`

- Independent Sum Cancellation (`independent-sum-cancellation`)

### Two-sample minimum: zero extension — `finite-two-sample-minimum`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Antitonic Sum Invariance (`antitonic-sum-consistency`)
- Archimedean Gambles (`archimedean-gambles`)
- Arroyo = ln 2 (`arroyo-value`)
- Comonotonic Sum Invariance (`comonotonic-sum-consistency`)
- Countable Sure-Thing (`countable-sure-thing`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Full Sum Invariance (`full-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Negative Affine Anti-Invariance (`negative-affine-anti-invariance`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Reflection Anti-Invariance (`reflection-anti-invariance`)
- Scale Invariance (`scale-invariance`)
- Shift Invariance (`shift-invariance`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)
- Sure-Thing (`sure-thing`)
- Symmetric Gambles Are Neutral (`symmetric-neutrality`)
- Universal Copula Sum Invariance (`universal-copula-sum-consistency`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4ⁿ] — `geometric-continuous-ultrafilter`

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)

### Folded-tail cone: lexicographic extension — `lexicographic-folded-extension`

- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Pasadena = ln 2 (`pasadena-value`)

### Lexicographic expectation: Hamel tie-break — `lexicographic-hamel-tie-break`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Countable Sure-Thing (`countable-sure-thing`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Transfer of a Shift Across a Mixture (`shift-transfer`)
- Simple Relative Expectation (`simple-relative-expectation`)

### Lexicographic expectation: nonatomic mass — `lexicographic-nonatomic-mass`

Fully determined; nothing unknown.

### Clipped expectation: continuous ultrafilter dominance [−4ⁿ, 4²ⁿ] — `polynomial-asymmetric-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Independent Sum Cancellation (`independent-sum-cancellation`)
- Independent Sum Invariance (`independent-sum-consistency`)
- Independent Sum Preservation (`independent-sum-preservation`)
- Integer Affine Preservation (`integer-affine-preservation`)
- Positive Affine Invariance (`positive-affine-invariance`)
- Rational Affine Preservation (`rational-affine-preservation`)
- Rational Scale Invariance (`rational-scale-invariance`)
- Scale Invariance (`scale-invariance`)

### Clipped expectation: continuous ultrafilter dominance — `total-continuous-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- CDF-Area Extension (`cdf-area-extension`)
- Existential Copula Sum Invariance (`existential-copula-sum-consistency`)
- Folded Expectation (`folded-expectation`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- L¹ Continuity (random variables) (`l1-continuity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)
- Relative Expectation (`relative-expectation`)
- Continuity under Vanishing Shifts (`vanishing-shift-continuity`)

### Clipped expectation: exact ultrafilter dominance — `total-exact-ultrafilter`

- Alternating St Petersburg = −1/2 (`alternating-st-petersburg-value`)
- Arroyo = ln 2 (`arroyo-value`)
- Uniqueness of Negative Self-Similarity (integer ratios) (`integer-negative-self-similarity`)
- Uniqueness of Negative Self-Similarity (`negative-self-similarity`)
- Pasadena = ln 2 (`pasadena-value`)

## 5. Open single-premise pairs (651)

*A ⇒ B ?* means neither implication nor incompatibility nor a countermodel is currently recorded. Grouped by antecedent. Most are open only because the obvious model has not been added.

- **Alternating St Petersburg = −1/2** (`alternating-st-petersburg-value`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Integer Affine Preservation, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)
- **Antitonic Sum Invariance** (`antitonic-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Countable Sure-Thing, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios), Universal Copula Sum Invariance
- **Archimedean Gambles** (`archimedean-gambles`) ⇒ Alternating St Petersburg = −1/2, Antitonic Sum Invariance, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Countable Sure-Thing, Existential Copula Sum Invariance, Expected Utility, Folded Expectation, Full Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios), Universal Copula Sum Invariance
- **Archimedean Outcomes** (`archimedean-outcomes`) ⇒ Restricted Stochastic Equivalence, Restricted Totality, Stochastic Equivalence
- **Arroyo = ln 2** (`arroyo-value`) ⇒ Archimedean Outcomes, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **CDF-Area Extension** (`cdf-area-extension`) ⇒ Existential Copula Sum Invariance, Mixture Independence, Rich Outcomes, Shift Invariance, Sure-Thing
- **Comonotonic Sum Invariance** (`comonotonic-sum-consistency`) ⇒ Archimedean Outcomes, Existential Copula Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, Integer Affine Preservation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Transfer of a Shift Across a Mixture
- **Continuity under Vanishing Shifts** (`vanishing-shift-continuity`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Countable Sure-Thing** (`countable-sure-thing`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Integer Affine Preservation, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)
- **Existential Copula Sum Invariance** (`existential-copula-sum-consistency`) ⇒ Archimedean Outcomes, Comonotonic Sum Invariance, Independent Sum Cancellation, Independent Sum Invariance, Independent Sum Preservation, Integer Affine Preservation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Transfer of a Shift Across a Mixture
- **Expected Utility** (`expected-utility`) ⇒ CDF-Area Extension, Existential Copula Sum Invariance, Mixture Independence, Relative Expectation, Rich Outcomes, Shift Invariance, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Folded Expectation** (`folded-expectation`) ⇒ Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **Full Sum Invariance** (`full-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Continuity under Vanishing Shifts, Countable Sure-Thing, Expected Utility, Folded Expectation, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)
- **Independent Sum Cancellation** (`independent-sum-cancellation`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, Independent Sum Invariance, Independent Sum Preservation, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)
- **Independent Sum Invariance** (`independent-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)
- **Independent Sum Preservation** (`independent-sum-preservation`) ⇒ Archimedean Outcomes, CDF-Area Extension, Comonotonic Sum Invariance, Continuity under Vanishing Shifts, Existential Copula Sum Invariance, Expected Utility, Independent Sum Cancellation, Independent Sum Invariance, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Integer Affine Preservation** (`integer-affine-preservation`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **L¹ Continuity (random variables)** (`l1-continuity`) ⇒ Archimedean Outcomes, CDF-Area Extension, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Transfer of a Shift Across a Mixture
- **Mixture Independence** (`independence`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Negative Affine Anti-Invariance** (`negative-affine-anti-invariance`) ⇒ Archimedean Outcomes, Integer Affine Preservation, Mixture Independence, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Pasadena = ln 2** (`pasadena-value`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Integer Affine Preservation, Mixture Independence, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)
- **Positive Affine Invariance** (`positive-affine-invariance`) ⇒ Archimedean Outcomes, Mixture Independence, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Rational Affine Preservation** (`rational-affine-preservation`) ⇒ Archimedean Outcomes, Rational Scale Invariance, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **Rational Scale Invariance** (`rational-scale-invariance`) ⇒ Archimedean Outcomes, Integer Affine Preservation, Rational Affine Preservation, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **Reflection Anti-Invariance** (`reflection-anti-invariance`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Relative Expectation** (`relative-expectation`) ⇒ Archimedean Outcomes, CDF-Area Extension, Existential Copula Sum Invariance, Expected Utility, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Restricted Stochastic Equivalence** (`restricted-stochastic-equivalence`) ⇒ Archimedean Outcomes, Restricted Totality, Stochastic Equivalence
- **Restricted Totality** (`restricted-totality`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Stochastic Equivalence
- **Rich Outcomes** (`rich-outcomes`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Stochastic Equivalence
- **Scale Invariance** (`scale-invariance`) ⇒ Archimedean Outcomes, Integer Affine Preservation, Mixture Independence, Rational Affine Preservation, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Shift Invariance** (`shift-invariance`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **Simple Expected Utility** (`simple-eu`) ⇒ Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **Simple Relative Expectation** (`simple-relative-expectation`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Statewise Dominance** (`statewise-dominance`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Stochastic Dominance, Stochastic Equivalence
- **Stochastic Dominance** (`stochastic-dominance`) ⇒ Archimedean Outcomes, Restricted Totality, Simple Expected Utility, Statewise Dominance
- **Stochastic Equivalence** (`stochastic-equivalence`) ⇒ Archimedean Outcomes, Restricted Totality
- **Sure-Thing** (`sure-thing`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence
- **Symmetric Gambles Are Neutral** (`symmetric-neutrality`) ⇒ Archimedean Outcomes, Arroyo = ln 2, Mixture Independence, Pasadena = ln 2, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Simple Expected Utility, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Totality** (`totality`) ⇒ Archimedean Outcomes, Restricted Stochastic Equivalence, Stochastic Equivalence
- **Transfer of a Shift Across a Mixture** (`shift-transfer`) ⇒ Archimedean Outcomes, Mixture Independence, Restricted Stochastic Equivalence, Restricted Totality, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing
- **Uniqueness of Negative Self-Similarity** (`negative-self-similarity`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Integer Affine Preservation, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture
- **Uniqueness of Negative Self-Similarity (integer ratios)** (`integer-negative-self-similarity`) ⇒ Alternating St Petersburg = −1/2, Archimedean Outcomes, Arroyo = ln 2, Continuity under Vanishing Shifts, Integer Affine Preservation, Mixture Independence, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Restricted Stochastic Equivalence, Restricted Totality, Scale Invariance, Shift Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity
- **Universal Copula Sum Invariance** (`universal-copula-sum-consistency`) ⇒ Alternating St Petersburg = −1/2, Archimedean Gambles, Archimedean Outcomes, Arroyo = ln 2, CDF-Area Extension, Continuity under Vanishing Shifts, Countable Sure-Thing, Expected Utility, Folded Expectation, Full Sum Invariance, Integer Affine Preservation, L¹ Continuity (random variables), Mixture Independence, Negative Affine Anti-Invariance, Pasadena = ln 2, Positive Affine Invariance, Rational Affine Preservation, Rational Scale Invariance, Reflection Anti-Invariance, Relative Expectation, Restricted Stochastic Equivalence, Restricted Totality, Rich Outcomes, Scale Invariance, Simple Expected Utility, Simple Relative Expectation, Statewise Dominance, Stochastic Dominance, Stochastic Equivalence, Sure-Thing, Symmetric Gambles Are Neutral, Totality, Transfer of a Shift Across a Mixture, Uniqueness of Negative Self-Similarity, Uniqueness of Negative Self-Similarity (integer ratios)

## 6. Deliberately deferred

`topics/unbounded-utility/extraction.md` has a section listing claims that were **not** recorded because they need a further reading of the sources. Those are marked deferred rather than open: the answer is likely in the literature and needs transcribing, not discovering. Read that section before starting work.

## 7. How to record an answer

- Proved an implication? Add `topics/unbounded-utility/results/<id>.yaml` with the full premise list and the proof.
- Refuted one? Add `topics/unbounded-utility/models/<id>.yaml` listing what you verified in `satisfies` and `violates`.
- Settling an existing conjecture? For a proof of the same statement, keep its ID, set `was_conjectured: true`, and change its status to `proved`. If the statement changes substantially, retain the original and add a separate record. Refuted proposals stay `status: conjectured`, with proved refuting evidence recorded separately. Answers under extra exploration assumptions are contextual, not global record statuses.
- Worked on a question without settling it? Put what you tried and what would settle it in the conjecture's `notes`; that alone earns it a bronze lynchpin star. Say in the notes whether you think it deserves silver or gold, by importance and difficulty, and why. Only a human sets `tier: silver` or `tier: gold`; an agent never does.
- Not sure? Add it with `status: conjectured`, an empty proof, and say in `notes` what would settle it.
- Then run `python3 scripts/pmap.py validate` and `status`. Never hand-edit the derived counts.

`README.md` has the exact record shapes and the sourcing rules. Follow them; an unsourced or misattributed record is worse than an absent one.
