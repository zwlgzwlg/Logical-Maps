# Countable Sure-Thing and Simple EU ⇒ Expected Utility?

**Refuted on the full measurable domain.** The original two-premise
proposal is preserved, with refutation supplied by the proved
[Lexicographic expectation: nonatomic mass](lexicographic-nonatomic-mass.html)
model. The model satisfies both stated premises and violates the
conclusion.

Take outcomes $[0,1]$ and rank all measurable gambles lexicographically by

$$V(X)=\bigl(E[X],c(\mathcal L(X))\bigr),$$

where $c$ is the total mass of the nonatomic part of a law. The linked
write-up proves Countable Sure-Thing for every countable measurable
partition, including the strict clause.

For $U$ uniform on $[0,1]$, the model has $U\succ1/2$ despite equal
finite expected utilities. Every simple law has second coordinate zero,
so Simple EU holds with the unique normalized chart $u(x)=x$.

The model also satisfies Totality, Stochastic Equivalence, Stochastic
Dominance, Mixture Independence and Sure-Thing. It violates Rich Outcomes.
With DU or DTU selected, Countable Sure-Thing instead conflicts with the
background by the recorded St Petersburg obstruction.

**Attribution and conjecture history.** Zachary Goodsell proposed this
arrow on 8 September 2026. GPT-6 (Codex) supplied the countermodel on
13 September, following Goodsell's request for proofs and a source check.
The original implication keeps its ID, premises and conjectured status;
the viewer computes its verdict from proved evidence and the selected
background. No independent checker or Lean proof is claimed.

**Russell–Isaacs source comparison.** *Infinite Prospects*, §§4–5 and
Appendix A, treats countably supported lotteries and complete
preferences. Its passage from acts to lotteries uses conditional-law
dependence. See the author's April 2020 manuscript, pp. 15–16, 22 and
25–26:
[author's manuscript](https://www.yoaavisaacs.com/uploads/6/9/2/0/69204575/infinite-prospects-final.pdf).
In the new model, $c$ vanishes on every countably supported law. Its
restriction to that domain is ordinary bounded EU; the counterexample
uses a nonatomic law. The published theorem therefore does not establish
the full-domain arrow recorded here.

