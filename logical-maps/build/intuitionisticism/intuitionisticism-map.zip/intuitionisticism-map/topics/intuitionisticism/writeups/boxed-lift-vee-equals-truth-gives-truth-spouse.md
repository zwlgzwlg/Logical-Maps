# □($\Diamond_\vee$ = Truth) ⇒ □Spouse ($\Diamond_\vee$)

<p class='cert'>Result — Source: Misc.; produced by Codex (GPT-6), connecting proof; recorded by Codex (GPT-6).</p>

## Premises

- **□($\Diamond_\vee$ = Truth).** $\Box$($\Diamond_\vee$ $= (\lambda p:t. p)$)

## Conclusion

- **□Spouse ($\Diamond_\vee$).** $\Box (\exists N:tt. \operatorname{Necessity}_{2}(N) \land \operatorname{Married}(N$, $\Diamond_\vee$))

## Proof

The recorded proof vee-equals-truth-gives-truth-spouse is an assumption-free II proof of its conclusion after all its displayed formula premises are discharged as a curried implication. Necessitate that closed implication. Starting from the boxed versions of exactly those premises, apply K once per premise to obtain the box of the entire conclusion. All object-language quantifiers stay inside their original boxes; no unboxed assumption is necessitated.

## Notes

Modal lifting of the separately recorded proof vee-equals-truth-gives-truth-spouse. Original mathematical credit remains in that record; this edge credits only the connecting lift. No independent checker or Lean verification.

## Sources

- **Codex connecting proofs, 13 Sep 2026** — Codex (GPT-6), connecting proof boxed-lift-vee-equals-truth-gives-truth-spouse, 2026-09-13.
- **Possibility in Intuitionistic Higher-Order Logic** — Zachary Goodsell, Possibility in Intuitionistic Higher-Order Logic (21 August 2026), §§4.2–4.5, pp. 18–27 (definitions/background).

<p class='cert'>Record: <code>topics/intuitionisticism/results/boxed-lift-vee-equals-truth-gives-truth-spouse.yaml</code></p>
