See [AGENTS.md](AGENTS.md) for the rules, [MAP.md](MAP.md) for the database, and [OPEN-QUESTIONS.md](OPEN-QUESTIONS.md) for what is unsettled.
